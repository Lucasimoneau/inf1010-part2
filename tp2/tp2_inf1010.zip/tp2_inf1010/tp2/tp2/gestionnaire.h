///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : gestionnaiere.h
//- Date : 23 Septembre 2019
//- Description : Cr�ation de la classe gestionnaire.
///

#ifndef GESTIONNAIRE_H
#define	GESTIONNAIRE_H

#include <vector>

#include "membre.h"

class Gestionnaire {
public:
	// Constructeurs
	Gestionnaire();

	~Gestionnaire();

	vector<Membre*> getMembres() const;

	vector<Coupon*> getCoupons() const;

	void ajouterMembre(const string& nomMembre);
	void ajouterCoupon(const string& code, double rabais, int cout);

	Membre* trouverMembre(const string& nomMembre) const; 

	void assignerBillet(const string& nomMembre, const string& pnr, double prixBase, const string& od, TarifBillet tarif, const string& dateVol, bool utiliserCoupon);
	
	double appliquerCoupon(Membre* membre, double prix);

	void acheterCoupon(const string& nomMembre);

	// TODO: Remplacer cette methode par l'operateur <<
	//void afficherInfos() const;

	friend ostream& operator<< (ostream &os, const Gestionnaire& gestionnaire);

private:
	// TODO: Convertir membres_ en vecteur
	//Membre** membres_;
	vector<Membre*> membres_;

	//int nbMembres_;
	//int capaciteMembres_;

	// TODO: Convertir coupons_ en vecteur
	//Coupon** coupons_;
	vector<Coupon*> coupons_;

	//int nbCoupons_;
	//int capaciteCoupons_;
};
#endif // !GESTIONNAIRE_H



