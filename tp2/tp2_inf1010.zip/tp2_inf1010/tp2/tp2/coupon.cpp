///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : coupon.cpp
//- Date : 23 Septembre 2019
//- Description : Cr�ation de la classe coupon.
///

#include "coupon.h"

Coupon::Coupon() : 
	code_(""),
	rabais_(0),
	cout_(0)
{
}

Coupon::Coupon(const string& code, double rabais, int cout) :
	code_(code),
	rabais_(rabais),
	cout_(cout)
{
}

Coupon::~Coupon()
{
}

string Coupon::getCode() const
{
	return code_;
}

double Coupon::getRabais() const
{
	return rabais_;
}

int Coupon::getCout() const
{
	return cout_;
}

void Coupon::setCode(const string& code)
{
	code_ = code;
}

void Coupon::setRabais(double rabais)
{
	rabais_ = rabais;
}

void Coupon::setCout(int cout)
{
	cout_ = cout;
}


///
//- Fonction : operator> 
//- Description : surcharge d operation pour afficher si le billet comparer est le plus grand
//- Param�tres : coupon2
//- Retour : bool
///
bool Coupon::operator>(const Coupon coupon2) {
	if (this->rabais_ > coupon2.rabais_) {
		return true;
	}
	return false;
}

///
//- Fonction : operator> 
//- Description : surcharge d operation pour afficher si le billet comparer est le plus petit
//- Param�tres : coupon2
//- Retour : bool
///
bool Coupon::operator<(const Coupon coupon2) {
	if (coupon2.rabais_ > this->rabais_) {
		return true;
	}
	return false;
}


// TODO: Remplacer cette methode par l'operateur <<
///
//- Fonction : operator<< 
//- Description : surcharge d operation pour l affichage
//- Param�tres : os, billet
//- Retour : ostream&
///
ostream& operator<< (ostream& os, const Coupon& coupon) {
	os<< "\t\t- Coupon " << coupon.getCode() << ". Rabais : " << coupon.getRabais() << "." << endl;
	return os;
}
