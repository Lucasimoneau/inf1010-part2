///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : membre.cpp
//- Date : 23 Septembre 2019
//- Description : Cr�ation de la classe membre.
///

#include "membre.h"

Membre::Membre() :
	nom_(""),
	points_(0)
	
{
}

Membre::Membre(const string& nom) :
	nom_(nom),
	points_(0)
{
}


///
//- Fonction : Membre::Membre
//- Description : constructeur par copie
//- Param�tres : membre
//- Retour : aucun
///
Membre::Membre(const Membre& membre) : nom_(membre.nom_), points_(membre.points_) {
	for (unsigned int i = 0; i < membre.billets_.size(); i++) {
		billets_.push_back(new Billet(*membre.billets_[i]));
	}
	
	for (unsigned int i = 0; i < membre.coupons_.size(); i++) {
		coupons_.push_back(membre.coupons_[i]);
	}

}


Membre::~Membre()
{
	for (unsigned int i = 0; i < billets_.size(); i++) {
		billets_.pop_back();
	}

	for (unsigned int i = 0; i < coupons_.size(); i++) {
		coupons_.pop_back();
	}

}

string Membre::getNom() const
{
	return nom_;
}

int Membre::getPoints() const
{
	return points_;
}

vector<Billet*> Membre::getBillets() const
{
	return billets_;
}

vector<Coupon*> Membre::getCoupons() const
{
	return coupons_;
}


void Membre::setNom(const string& nom)
{
	nom_ = nom;
}

void Membre::modifierPoints(int points)
{
	points_ += points;
}

void Membre::ajouterBillet(const string& pnr, double prix, const string& od, TarifBillet tarif, const string& dateVol)
{

	Billet* billet = new Billet(pnr, nom_, prix, od, tarif, dateVol);
	billets_.push_back(billet);
	modifierPoints(calculerPoints(billet));
}

///
//- Fonction : acheterCoupon
//- Description : fonction qui permet d acheter un coupon a l aide de l operateur+=
//- Param�tres : coupon
//- Retour : aucun
///
void Membre::acheterCoupon(Coupon* coupon)
{
	if (points_ > coupon->getCout()) {
		// TODO: Utiliser la surcharge de l'operateur += de la classe Membre plutot qu'utiliser la methode ajouterCoupon
		*this += coupon;
		// coupons_ = void + coupon

		modifierPoints(-coupon->getCout());
	}
}

double  Membre::calculerPoints(Billet * billet) const
{
	double bonus = 0;
	switch (billet->getTarif()) {
	case TarifBillet::PremiumEconomie:
		bonus = 50;
		break;
	case TarifBillet::Affaire:
		bonus = 150;
		break;
	case TarifBillet::Premiere:
		bonus = 300;
		break;
	default:
		break;
	}

	return billet->getPrix()* 0.10 + bonus;
}

// TODO: Remplacer cette methode par l'operateur +=
///
//- Fonction : operator+=
//- Description : operateur qui permet d ajouter un coupon au vecteur
//- Param�tres : coupon
//- Retour : this
///
Membre& Membre::operator+=(Coupon* coupon) {

	coupons_.push_back(coupon);
	return *this;

}


// TODO: Remplacer cette methode par l'operateur -=
///
//- Fonction : operator_=
//- Description : operateur qui permet d enlever un coupon au vecteur
//- Param�tres : coupon
//- Retour : this
///

Membre& Membre::operator-=(Coupon* coupon) {
	for (int i = 0; i < coupons_.size(); i++) {
		if (coupons_[i] == coupon) {
			for (int j = i; j < coupons_.size() - 1; j++) {
				coupons_[j] = coupons_[j + 1];
			}
			coupons_.pop_back();
			return *this;
		}
	}
}

// TODO: Surcharger l'operateur == (operande de gauche est un membre et droite est un string)
///
//- Fonction : operator==
//- Description : operateur qui permet de dire si le nom = au nom comparer
//- Param�tres : nom
//- Retour : bool
///
bool Membre::operator==(const string nom) {
	if (nom == this->getNom()) {
		return true;
	}
	return false;

}


// TODO: Surcharger l'operateur == (operande de gauche est un string et droite est un membre)
///
//- Fonction : operator==
//- Description : operateur qui permet de dire si le nom = au nom comparer
//- Param�tres : nom
//- Retour : bool
///
 bool operator==(string nom, const Membre membre11) {
	if (membre11.getNom() == nom) {
		return true;
	}
	return false;

}


// TODO: Surcharger l'operateur =
///
//- Fonction : operator=
//- Description : operateur qui permet d ecraser les attributs du membre par les attributs
//- Param�tres : membre
//- Retour : this
///
Membre& Membre::operator=(const Membre& membre) {
	if (this != &membre) {
		for (unsigned i = 0; i < billets_.size(); i++) {
			delete billets_[i];
		}

		for (unsigned i = 0; i < coupons_.size(); i++) {
			coupons_.pop_back();
		}

		nom_ = membre.nom_;
		points_ = membre.points_;
		coupons_ = membre.coupons_;

		for (unsigned i = 0; i < coupons_.size()-1; i++) {
			billets_.push_back(new Billet(*membre.billets_[i])) ;
		}
		
	}
	return *this;

}


// TODO: Remplacer cette methode par la surcharge de l'operateur <<
///
//- Fonction : operator<< 
//- Description : surcharge d operation pour l affichage
//- Param�tres : os, billet
//- Retour : ostream&
///
ostream& operator<< (ostream& os, const Membre& membre) {

	os << setfill(' ');
	os << "- Membre " << membre.getNom() << ":" << endl;
	os << "\t" << left << setw(10) << "- Points" << ": " << membre.getPoints() << endl;
	os << "\t" << "- Billets :" << endl;
	for (int i = 0; i < membre.getBillets().size(); i++) {
		os<<*membre.getBillets()[i];
		
	}
	os << "\t" << "- Coupons :" << endl;
	for (int i = 0; i < membre.getCoupons().size(); i++) {
		os <<*membre.getCoupons()[i];
		
	}
	os << endl;

	return os;


}

