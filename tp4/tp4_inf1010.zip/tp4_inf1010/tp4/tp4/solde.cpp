///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : solde.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe solde.
///

#include "solde.h"

Solde::Solde(double pourcentageSolde)
{
	pourcentageSolde_ = pourcentageSolde;
}

Solde::~Solde()
{
}

double Solde::getPourcentageSolde() const
{
	return pourcentageSolde_;
}

void Solde::setPourcentageSolde(double pourcentageSolde)
{
	pourcentageSolde_ = pourcentageSolde;
}
