///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : flightPassSolde.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe flightPassSolde.
///

#include "flightPassSolde.h"


///
//- Fonction : FlightPassSolde::FlightPassSolde
//- Description : constructeur par parametre
//- Param�tres : pnr, prix, od, tarif, pourcentageSolde
//- Retour : Aucun
///
FlightPassSolde::FlightPassSolde(const string& pnr, double prix, const string& od, TarifBillet tarif, double pourcentageSolde):
	FlightPass(pnr,prix,od,tarif),
	Solde(pourcentageSolde)
{
}

///
//- Fonction : FlightPassSolde::getPrix
//- Description : fonction qui permet de get le prix d un billet apres la reduction
//- Param�tres : Aucun
//- Retour : double
///
double FlightPassSolde::getPrix() const
{
	double prix = prix_ * (1 - pourcentageSolde_);
	return prix;
}

///
//- Fonction : FlightPassSolde::getPrixBase
//- Description : fonction qui permet de get le prix de base
//- Param�tres : Aucun
//- Retour : double
///
double FlightPassSolde::getPrixBase()
{
	return prix_;
}


///
//- Fonction : FlightPassSolde::clone
//- Description : fonction qui permet de cloner un flightPassSolde
//- Param�tres : Aucun
//- Retour : FlightPassSolde*
///
FlightPassSolde* FlightPassSolde::clone()
{
	FlightPassSolde* billet = new FlightPassSolde(*this);
	return billet;
}


///
//- Fonction : FlightPassSolde::afficher
//- Description : fonction qui permet d afficher un flightpassSolde
//- Param�tres : o
//- Retour : aucun
///
void FlightPassSolde::afficher(ostream& o)
{
	FlightPass::afficher(o);
	o << "\t\t\t" << setw(11) << "- Pourcentage solde: " << pourcentageSolde_ << "%" << endl;

}