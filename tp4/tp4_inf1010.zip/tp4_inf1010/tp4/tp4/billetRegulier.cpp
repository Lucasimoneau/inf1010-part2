///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : billetRegulier.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe billetRegulier.
///

#include "billetRegulier.h"

BilletRegulier::BilletRegulier(const string& pnr, double prix, const string& od, TarifBillet tarif, const string& dateVol) : 
	Billet(pnr, prix, od, tarif), dateVol_(dateVol)
{
}

string BilletRegulier::getDateVol() const
{
	return dateVol_;
}

void BilletRegulier::setDateVol(string dateVol)
{
	dateVol_ = dateVol;
}


///
//- Fonction : BilletRegulier::clone
//- Description : fonction qui permet de cloner un billet regulier
//- Param�tres : aucun
//- Retour : BilletRegulier*
///
BilletRegulier* BilletRegulier::clone()
{
	BilletRegulier* billet = new BilletRegulier(*this);
	return billet;
}


///
//- Fonction : BilletRegulier::afficher
//- Description : fonction qui permet d afficher un billet regulier
//- Param�tres : o
//- Retour : Aucun
///
void BilletRegulier::afficher(ostream& o)
{
	Billet::afficher(o);
	o << "\t\t\t" << setw(11) << "- Vol le" << ": " << dateVol_ << endl;
	
	
}