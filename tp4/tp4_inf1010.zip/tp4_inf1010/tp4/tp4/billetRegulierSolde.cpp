///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : billetRegulierSolde.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe billetRegulierSolde.
///

#include "billetRegulierSolde.h"

///
//- Fonction : BilletRegulierSolde::BilletRegulierSolde
//- Description : constructeur par parametre
//- Param�tres : pnr, prix, od , tarif, dateVol, pourcentageVol
//- Retour : Aucun
///
BilletRegulierSolde::BilletRegulierSolde(const string& pnr, double prix, const string& od, TarifBillet tarif, const string& dateVol, double pourcentageSolde):
	BilletRegulier(pnr, prix,od,tarif,dateVol),
	Solde(pourcentageSolde)
{
}


///
//- Fonction : BilletRegulierSolde::getPrix
//- Description : fonction qui permet de get le prix
//- Param�tres : Aucun
//- Retour : double
///
double BilletRegulierSolde::getPrix() const
{
	double prix = prix_*(1-pourcentageSolde_);
	return prix;
}

///
//- Fonction : BilletRegulierSolde::getPrixBase
//- Description : fonction qui permet de get le prix de Base
//- Param�tres : Aucun
//- Retour : double
///
double BilletRegulierSolde::getPrixBase()
{
	return prix_;				
}

///
//- Fonction : BilletRegulierSolde::clone
//- Description : fonction qui permet de clone un billet regulier en solde
//- Param�tres : Aucun
//- Retour : BilletRegulierSolde*
///
BilletRegulierSolde* BilletRegulierSolde::clone()
{
	BilletRegulierSolde* billet = new BilletRegulierSolde(*this);
	return billet;

}

///
//- Fonction : BilletRegulierSolde::afficher
//- Description : fonction qui permet d afficher un billet regulier en solde
//- Param�tres : o
//- Retour : aucun
///
void BilletRegulierSolde::afficher(ostream& o)
{
	BilletRegulier::afficher(o);
	o << "\t\t\t" << setw(11) << "- Pourcentage solde: "  << pourcentageSolde_ << "%"<< endl;
}