///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : gestionnaire.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe gestionnaire.
///

#include "gestionnaire.h"

Gestionnaire::Gestionnaire()
{
}

Gestionnaire::~Gestionnaire()
{
	for (size_t i = 0; i < membres_.size(); ++i) {
		delete membres_[i];
	}

	for (size_t i = 0; i < coupons_.size(); ++i) {
		delete coupons_[i];
	}
}

vector<Membre*> Gestionnaire::getMembres() const
{
	return membres_;
}

vector<Coupon*> Gestionnaire::getCoupons() const
{
	return coupons_;
}

void Gestionnaire::ajouterMembre(Membre* membre)
{
	membres_.push_back(membre);
}

void Gestionnaire::ajouterCoupon(Coupon* coupon)
{
	coupons_.push_back(coupon);
}

Membre* Gestionnaire::trouverMembre(const string& nomMembre) const
{
	for (size_t i = 0; i < membres_.size(); ++i) {
		if (*membres_[i] == nomMembre) {
			return membres_[i];
		}
	}
	cout << "Le membre " << nomMembre << " n'existe pas\n";

	return nullptr;
}

///
//- Fonction : Gestionnaire::assignerBillet
//- Description : fonction qui permet d assigner un billet
//- Param�tres : billet, nomMembre, utiliserCoupon
//- Retour : aucun
///
void Gestionnaire::assignerBillet(Billet* billet, const string& nomMembre, bool utiliserCoupon)
	{
	Membre* membre = trouverMembre(nomMembre);
	double prix = 0;

	if (membre == nullptr) {
		delete billet;
		return;
	}

	if (auto solde = dynamic_cast<Solde*>(billet)) {
		prix = solde->getPrixBase();
	}

	else {
		prix = billet->getPrix();
	}
	

	if (utiliserCoupon) {
		prix -= appliquerCoupon(membre, prix);
	}

	if (auto premium = dynamic_cast<MembrePremium*>(membre)) {
		double rabais = 0.005 * static_cast<MembrePremium*>(membre)->getpointsCumulee() / 1000;
		if (rabais > 0.1)
			rabais = 0.1;

		prix *= (1 - rabais);
		billet->setPrix(prix);
		premium->ajouterBillet(billet);
		
	}
	else if (auto regulier = dynamic_cast<MembreRegulier*>(membre)) {
		billet->setPrix(prix);
		regulier->ajouterBillet(billet);
	}
	else{
		billet->setPrix(prix);
		membre->ajouterBillet(billet);
		
	}
	
}

double Gestionnaire::appliquerCoupon(Membre* membre, double prix)
{
	MembreRegulier* membreReg = dynamic_cast<MembreRegulier*>(membre);

	if (!membreReg || membreReg->getCoupons().size() == 0) {
		cout << "Le membre n'a pas de coupon utilisable\n";
		return 0;
	}

	Coupon* meilleurCoupon = membreReg->getCoupons()[0];
	vector<Coupon*> coupons = membreReg->getCoupons();
	for (size_t i = 1; i < coupons.size(); ++i) {
		if (*coupons[i] > *meilleurCoupon) {
			meilleurCoupon = coupons[i];
		}
	}

	*membreReg -= meilleurCoupon;

	return prix * meilleurCoupon->getRabais();
}

void Gestionnaire::acheterCoupon(const string& nomMembre)
{
	if (coupons_.size() == 0) {
		cout << "Le gestionnaire n'a pas de coupon!" << endl;
		return;
	}

	Membre* membre = trouverMembre(nomMembre);

	if (membre == nullptr) {
		return;
	}

	Coupon* meilleurCoupon = nullptr;

	if (auto membreRegulier = dynamic_cast<MembreRegulier*>(membre)) {
		for (size_t i = 0; i < coupons_.size(); ++i) {
			if (membreRegulier->peutAcheterCoupon(coupons_[i])) {
				if (meilleurCoupon == nullptr) {
					meilleurCoupon = coupons_[i];
				}
				else if (*coupons_[i] > * meilleurCoupon) {
					meilleurCoupon = coupons_[i];
				}
			}
		}
		if (meilleurCoupon) {
			membreRegulier->acheterCoupon(meilleurCoupon);
		}
		else {
			cout << "Le membre ne peut acheter de coupon\n";
		}
	}
	else {
		cout << "Le membre ne peut acheter de coupon\n";
	}
}

///
//- Fonction : Gestionnaire::calculerRevenu
//- Description : fonction qui permet de calculer les revenu
//- Param�tres : aucun
//- Retour : double
///
double Gestionnaire::calculerRevenu()
{
	double revenu = 0;
	for (unsigned int i = 0; i < membres_.size(); i++) {
		for (unsigned int j = 0; j < membres_[i]->getBillets().size(); j++) {
			revenu += membres_[i]->getBillets()[j]->getPrix();
		}
	}
	return revenu;
}

///
//- Fonction : Gestionnaire::calculerNombreBilletsEnSolde
//- Description : fonction qui permet de calculer le nombre de billets en solde
//- Param�tres : aucun
//- Retour : int
///
int Gestionnaire::calculerNombreBilletsEnSolde()
{
	int nbBilletSolde = 0;
	for (unsigned int i = 0; i < membres_.size(); i++) {
		for (unsigned int j = 0; j < membres_[i]->getBillets().size(); j++) {
			if (auto billetSolde= dynamic_cast<Solde*>(membres_[i]->getBillets()[j])) {
				nbBilletSolde++;
			}
		}
	}
	return nbBilletSolde;
}


///
//- Fonction : Gestionnaire::afficher
//- Description : fonction qui permet d afficher le gestionnaire
//- Param�tres : o
//- Retour : aucun
///
void Gestionnaire::afficher(ostream& o)
{
	o << "=================== ETAT ACTUEL DU PROGRAMME ==================\n\n";

	for (int i = 0; i < membres_.size(); ++i) {
		if (auto premium = dynamic_cast<MembrePremium*>(membres_[i])) {
			premium->afficher(o);
		}
		else if (auto regulier = dynamic_cast<MembreRegulier*>(membres_[i])) {
			regulier->afficher(o);
		}
		else {
			membres_[i]->afficher(o);
		}
		
		
	}
}