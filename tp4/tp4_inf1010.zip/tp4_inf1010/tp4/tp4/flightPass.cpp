///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : flightPass.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe flightPass.
///

#include "flightPass.h"

FlightPass::FlightPass(const string& pnr, double prix, const string& od, TarifBillet tarif) : 
	Billet(pnr, prix, od, tarif), nbUtilisationsRestante_(NB_UTILISATIONS_INITIALE)
{
}

int FlightPass::getNbUtilisationsRestante() const
{
	return nbUtilisationsRestante_;
}

void FlightPass::decrementeNbUtilisations()
{
	--nbUtilisationsRestante_;
}

///
//- Fonction : FlightPass::clone
//- Description : fonction qui permet de cloner un flightpass
//- Param�tres : Aucun
//- Retour : FlightPass*
///
FlightPass* FlightPass::clone()
{
	FlightPass* billet = new FlightPass(*this);
	return billet;
}

///
//- Fonction : FlightPass::afficher
//- Description : fonction qui permet d afficher un flighpass
//- Param�tres : o
//- Retour : aucun
///
void FlightPass::afficher(ostream& o)
{
	Billet::afficher(o);
	o << "\t\t\t" << setw(11) << "- Utilisation restantes: " << nbUtilisationsRestante_ << endl;

}