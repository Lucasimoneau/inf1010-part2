///
//- Auteurs : Arthur Leboiteux, Lucas Simoneau
//- Fichier : membre.cpp
//- Date : 15 Octobre 2019
//- Description : Cr�ation de la classe membre.
///
#include "membre.h"

Membre::Membre() :
	nom_("")
{
}

Membre::Membre(const string& nom) :
	nom_(nom)
{
}

///
//- Fonction : Membre::Membre
//- Description : constructeur par copie
//- Param�tres : membre
//- Retour : aucun
///
Membre::Membre(const Membre& membre) :
	nom_(membre.nom_)
{
	for (size_t i = 0; i < membre.billets_.size(); ++i) {
		billets_.push_back(membre.billets_[i]->clone());
		
	}
}

Membre::~Membre()
{
	for (size_t i = 0; i < billets_.size(); ++i) {
		delete billets_[i];
	}
}

string Membre::getNom() const
{
	return nom_;
}

vector<Billet*> Membre::getBillets() const
{
	return billets_;
}

void Membre::setNom(const string& nom)
{
	nom_ = nom;
}


///
//- Fonction : Membre::utiliserBillet
//- Description : fonction qui permet d utiliser un billet
//- Param�tres : pnr
//- Retour : aucun
///
void Membre::utiliserBillet(const string& pnr)
{
	int indexTrouve = -1;
	for (size_t i = 0; i < billets_.size(); ++i) {
		if (billets_[i]->getPnr() == pnr) {
			indexTrouve = i;
			break;
		}
	}

	if (indexTrouve == -1) {
		cout << "Le billet n'est pas trouve" << endl;
		return;
	}

	if (auto flightPass = dynamic_cast<FlightPass*>(billets_[indexTrouve])) {
		flightPass->decrementeNbUtilisations();
		if (flightPass->getNbUtilisationsRestante() > 0) {
			return;
		}
	}

	delete billets_[indexTrouve];
	billets_[indexTrouve] = billets_[billets_.size() - 1];
	billets_.pop_back();
}

void Membre::ajouterBillet(Billet* billet)
{
	billet->setNomPassager(nom_);
	billets_.push_back(billet);
}

bool Membre::operator==(const string& nomMembre) const
{
	return nom_ == nomMembre;
}

bool operator==(const string& nomMembre, const Membre& membre)
{
	return nomMembre == membre.nom_;
}

///
//- Fonction : Membre::operator=
//- Description : fonction operateur =
//- Param�tres : membre
//- Retour : Membre&
///
Membre& Membre::operator=(const Membre& membre)
{
	if (this != &membre) {
		nom_ = membre.nom_;

		for (size_t i = 0; i < billets_.size(); ++i) {
			delete billets_[i];
		}

		billets_.clear();

		for (size_t i = 0; i < membre.billets_.size(); ++i) {
			billets_.push_back(membre.billets_[i]->clone());
			
		}
	}

	return *this;
}


///
//- Fonction : Membre::afficher
//- Description : fonction qui permet d afficher un membre
//- Param�tres : o
//- Retour : aucun
///
void Membre::afficher(ostream& o)
{
	o << setfill(' ');
	o << "- Membre " << nom_ << ":" << endl;
	o << "\t" << "- Billets :" << endl;
	for (size_t i = 0; i < billets_.size(); i++) {
		
		if (auto flightPass = dynamic_cast<FlightPass*>(billets_[i])) {
			flightPass->afficher(o);
		}
		else if (auto regulier = dynamic_cast<BilletRegulier*>(billets_[i])) {
			regulier->afficher(o);
		}
		else {
			billets_[i]->afficher(o);
		}
		
	}
	

}