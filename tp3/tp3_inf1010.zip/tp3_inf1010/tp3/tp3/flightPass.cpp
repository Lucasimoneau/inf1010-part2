///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : flightPass.cpp
//- Date : 8 Octobre 2019
//- Description : Cr�ation de la classe flight pass.
///

#include "flightPass.h"


///
//- Fonction : FlightPass
//- Description : fonction qui permet d initialiser les attributs d un flight pass .
//- Param�tres : pnr, nomPassager, prix, od, tarif, typeBillet
//- Retour : aucun
///
FlightPass::FlightPass(const string& pnr, const string& nomPassager, double prix, const string& od, TarifBillet tarif, TypeBillet typeBillet):
	Billet(pnr, nomPassager,prix,od ,tarif,typeBillet),
	nbUtilisationsRestante_(NB_UTILISATIONS_INITIALE)
{
	
}

///
//- Fonction : decrementeNbUtilisations
//- Description : fonction qui permet de decrementer le nombre d utilisation d un flight pass
//- Param�tres : aucun
//- Retour : aucum
///
void FlightPass::decrementeNbUtilisations() {
	if (nbUtilisationsRestante_ > 0) {
		nbUtilisationsRestante_--;
		return;
	}
	cout << "erreur il n y a plus d utilisation flight pass" << endl;

}


///
//- Fonction : getNbUtilisationsRestante
//- Description : fonction qui permet de get le nombre d utilisation restante
//- Param�tres : aucun
//- Retour : int
///
int FlightPass::getNbUtilisationsRestante() const {
	return nbUtilisationsRestante_;

}

///
//- Fonction : operator<<
//- Description : fonction qui permet d'afficher un flght pass
//- Param�tres : os, flightpass
//- Retour : ostream
///
ostream& operator<<(ostream& os, const FlightPass& flightpass) {

	os << "\t\t\t" << "-Utilisation restantes:  " << flightpass.getNbUtilisationsRestante() << endl;

	return os;
}
