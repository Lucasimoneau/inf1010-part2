///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : gestiojnnaire.cpp
//- Date : 8 Octobre 2019
//- Description : Cr�ation de la classe gestiojnnaire.
///

#include "gestionnaire.h"

Gestionnaire::Gestionnaire()
{
}

Gestionnaire::~Gestionnaire()
{
	for (int i = 0; i < membres_.size(); i++) {
		delete membres_[i];
	}

	for (int i = 0; i < coupons_.size(); i++) {
		delete coupons_[i];
	}
}

vector<Membre*> Gestionnaire::getMembres() const
{
	return membres_;
}

vector<Coupon*> Gestionnaire::getCoupons() const
{
	return coupons_;
}

void Gestionnaire::ajouterMembre(const string& nomMembre, TypeMembre typeMembre)
{
	
	if (typeMembre == Membre_Occasionnel) {
		membres_.push_back(new Membre(nomMembre, typeMembre));
	}
	else if (typeMembre == Membre_Regulier) {
		membres_.push_back(new MembreRegulier(nomMembre, typeMembre));
	}
	else if (typeMembre == Membre_Premium) {
		membres_.push_back(new MembrePremium(nomMembre));

	}
	
	
}

void Gestionnaire::ajouterCoupon(const string& code, double rabais, int cout)
{
	coupons_.push_back(new Coupon(code, rabais, cout));
}

Membre* Gestionnaire::trouverMembre(const string& nomMembre) const
{
	for (int i = 0; i < membres_.size(); i++) {
		if (*membres_[i] == nomMembre) {
			return membres_[i];
		}
	}
	cout << "Le membre " << nomMembre << " n'existe pas\n";

	return nullptr;
}

///
//- Fonction : assignerBillet
//- Description : fonction qui permet d assigner un billet
//- Param�tres : nomMembre, pnr, prixBase, od , tarif,datevol, utiliserCoupon, typeBillet
//- Retour : aucun
///
void Gestionnaire::assignerBillet(const string& nomMembre, const string& pnr, double prixBase, const string& od, TarifBillet tarif, const string& dateVol, bool utiliserCoupon, TypeBillet typeBillet)
{
	double prixReel;
	Membre* membre = trouverMembre(nomMembre);

	if (membre == nullptr) {
		return;
	}

	if (typeBillet == Flight_Pass) {
		prixBase *= 10;
	}

	if (membre->getTypeMembre() == Membre_Premium) {
		MembrePremium* membrePremium = static_cast<MembrePremium*>(membre);
		double rabais = 100 - ((membrePremium->getpointsCumulee() / 1000)*0.5);
		if (rabais < 90) {
			rabais = rabais;
		}
		prixBase *= (rabais / 100);

		if (utiliserCoupon) {
			prixReel = prixBase - appliquerCoupon(membre, prixBase);
		}
		else {
			prixReel = prixBase;
		}
		membrePremium->ajouterBillet(pnr, prixReel, od, tarif, typeBillet, dateVol);

	}

	else {
		if (utiliserCoupon) {
			prixReel = prixBase - appliquerCoupon(membre, prixBase);
		}
		else {
			prixReel = prixBase;
		}
		if (membre->getTypeMembre() == Membre_Regulier) {
			MembreRegulier* membreRegulier = static_cast<MembreRegulier*>(membre);
			membreRegulier->ajouterBillet(pnr, prixReel, od, tarif, typeBillet, dateVol);
		}
		else if (membre->getTypeMembre() == Membre_Occasionnel) {
			membre->ajouterBillet(pnr, prixReel, od, tarif, typeBillet, dateVol);
		}
	}
}


///
//- Fonction : appliquerCoupon
//- Description : fonction qui permet d appliquer un coupon
//- Param�tres : membre, prix
//- Retour : double
///
double Gestionnaire::appliquerCoupon(Membre* membre, double prix)
{
	if (membre->getTypeMembre() == Membre_Occasionnel) {
		cout << "erreur, le membre est un membre occasionnel , il n'a pas acces aux coupons" << endl;
		return 0;
	}
	
	MembreRegulier* membreRegulier = static_cast<MembreRegulier*>(membre);

	if (membreRegulier->getCoupons().size() == 0) {
		cout << "Le membre n'a pas de coupon utilisable\n";
		return 0;
	}

	Coupon* meilleurCoupon = membreRegulier->getCoupons()[0];
	vector<Coupon*> coupons = membreRegulier->getCoupons();
	for (int i = 1; i < coupons.size(); ++i) {
		if (*coupons[i] > *meilleurCoupon) {
			meilleurCoupon = coupons[i];
		}
	}

	*membreRegulier -= meilleurCoupon;

	return prix * meilleurCoupon->getRabais();
}


///
//- Fonction : acheterCoupon
//- Description : fonction qui permet d acheter un coupon
//- Param�tres : nomMembre
//- Retour : aucun
///
void Gestionnaire::acheterCoupon(const string& nomMembre)
{
	if (coupons_.size() == 0) {
		cout << "Le gestionnaire n'a pas de coupon!" << endl;
		return;
	}

	Membre* membre = trouverMembre(nomMembre);
	MembreRegulier* membreRegulier = static_cast<MembreRegulier*>(membre);

	if (membre == nullptr) {
		return;
	}
	
	Coupon* meilleurCoupon = nullptr;

	for (int i = 0; i < coupons_.size(); i++) {
		if (membreRegulier->getPoints() >= coupons_[i]->getCout()) {
			// Si on avait pas encore trouve de meilleur coupon, on fait la premiere assignation
			if (meilleurCoupon == nullptr) {
				meilleurCoupon = coupons_[i];
			}
			// Sinon on compare si le coupon courant a un rabais superieur au meilleur coupon
			else if (*coupons_[i] > *meilleurCoupon) {
				meilleurCoupon = coupons_[i];
			}
		}
	}


	if (meilleurCoupon) {
		if (membreRegulier->getTypeMembre() == Membre_Premium) {
			MembrePremium* membrePremium = static_cast<MembrePremium*>(membreRegulier);
			double rabais = (100 - ((membrePremium->getpointsCumulee() / 1000) * 1)) / 100;
			if (rabais < 0.80) {
				rabais = 0.80;
			}
			meilleurCoupon->setCout((meilleurCoupon->getCout())*rabais);
			membrePremium->acheterCoupon(meilleurCoupon);
		}
		else {
			membreRegulier->acheterCoupon(meilleurCoupon);
		}
	}

	else {
		cout << "Le membre ne peut acheter de coupon\n";
	}
}


///
//- Fonction : operator<<
//- Description : fonction qui permet d afficher un gestionnaire
//- Param�tres : o , gestionnaire
//- Retour : ostream
///
ostream& operator<<(ostream& o, const Gestionnaire& gestionnaire)
{
	o << "=================== ETAT ACTUEL DU PROGRAMME ==================\n\n";
	for (int i = 0; i < gestionnaire.membres_.size(); i++) {
		o << *gestionnaire.membres_[i];
		if (gestionnaire.membres_[i]->getTypeMembre() == Membre_Regulier ||
			gestionnaire.membres_[i]->getTypeMembre() == Membre_Premium) {
			MembreRegulier* membreRegulier = static_cast<MembreRegulier*>(gestionnaire.membres_[i]);
			o << *membreRegulier;

			if (gestionnaire.membres_[i]->getTypeMembre() == Membre_Premium) {
				MembrePremium* membrePremium = static_cast<MembrePremium*>(gestionnaire.membres_[i]);
				o << *membrePremium;
			}
		}
		
	}

	return o;
}
