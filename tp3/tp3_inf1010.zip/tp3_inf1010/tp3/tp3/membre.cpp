///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : membre.cpp
//- Date : 8 Octobre 2019
//- Description : Cr�ation de la classe membre.
///

#include "membre.h"

///
//- Fonction : Membre
//- Description : fonction qui permet d initialiser les attributs de membre 
//- Param�tres : aucun
//- Retour : aucun
///
Membre::Membre() :
	nom_(""),
	typeMembre_(Membre_Regulier)
{
}


///
//- Fonction : Membre
//- Description : fonction qui permet d initialiser les attributs de membre avec des paramatres
//- Param�tres : nom, typeMembre
//- Retour : aucun
///
Membre::Membre(const string& nom, TypeMembre typeMembre) :
	nom_(nom),
	typeMembre_(typeMembre)
{
}



///
//- Fonction : Membre
//- Description : fonction constructeur par copie
//- Param�tres : membre
//- Retour : aucun
///
Membre::Membre(const Membre& membre) :
	nom_(membre.nom_),
	typeMembre_(membre.typeMembre_)
{
	for (int i = 0; i < membre.billets_.size(); ++i) {
		Billet* billet = new Billet(*membre.billets_[i]);
		if (billet->getTypeBillet() == Billet_Base) {
			billets_.push_back(billet);
		}

		else if (billet->getTypeBillet() == Billet_Regulier) {
			BilletRegulier* nouveauBillet = static_cast<BilletRegulier*>(billet);
			billets_.push_back(nouveauBillet);
		}

		else if (billet->getTypeBillet() == Flight_Pass) {
			FlightPass* nouveauBillet = static_cast<FlightPass*>(billet);
			billets_.push_back(nouveauBillet);
		}
	}
}

Membre::~Membre()
{
	for (int i = 0; i < billets_.size(); i++) {
		delete billets_[i];
	}
}

string Membre::getNom() const
{
	return nom_;
}

TypeMembre Membre::getTypeMembre() const {
	return typeMembre_;
}

vector<Billet*> Membre::getBillets() const
{
	return billets_;
}


void Membre::setNom(const string& nom)
{
	nom_ = nom;
}

///
//- Fonction : utiliserBillet
//- Description : fonction qui permet d utiliser un billet
//- Param�tres : pnr
//- Retour : aucun
///
void Membre::utiliserBillet(const string& pnr) {
	for (int i = 0; i < billets_.size(); i++) {
		if (billets_[i]->getPnr() == pnr) {
			if (billets_[i]->getTypeBillet() == Flight_Pass) {
				FlightPass* billetFlightPass = static_cast<FlightPass*>(billets_[i]);
					billetFlightPass->decrementeNbUtilisations();
				if (billetFlightPass->getNbUtilisationsRestante() == 0) {
					delete billetFlightPass;
					for (int j = i; j < billets_.size()-1; j++) {
						billets_[j] = billets_[j + 1];
					}
					billets_.pop_back();
				}

			}
			else {
				for (int j = i; j < billets_.size() - 1; j++) {
					billets_[j] = billets_[j + 1];
				}
				billets_.pop_back();
			}
			return;
		}
		
	}

	cout << "le billet n a pas ete trouve a l aide du pnr" << endl;


}


///
//- Fonction : ajouterBillet
//- Description : fonction qui permet d ajouter un billet 
//- Param�tres : pnr, prix, od, tarif, typeBillet, dateVol
//- Retour : aucun
///
void Membre::ajouterBillet(const string& pnr, double prix, const string& od, TarifBillet tarif, TypeBillet typeBillet, const string& dateVol)
{
	
	if (typeBillet == Billet_Base) {
		Billet* nouveauBillet = new Billet(pnr, nom_, prix, od, tarif, typeBillet);
		billets_.push_back(nouveauBillet);
	}

	else if (typeBillet == Billet_Regulier) {
		BilletRegulier* nouveauBillet = new BilletRegulier (pnr, nom_, prix, od, tarif, dateVol, typeBillet);
		billets_.push_back(nouveauBillet);
	}

	else if (typeBillet == Flight_Pass) {
		FlightPass* nouveauBillet = new FlightPass(pnr, nom_, prix, od, tarif, typeBillet);
		billets_.push_back(nouveauBillet);
	}
	
}



bool Membre::operator==(const string& nomMembre) const
{
	return nom_ == nomMembre;
}

bool operator==(const string& nomMembre, const Membre& membre)
{
	return nomMembre == membre.nom_;
}

Membre& Membre::operator=(const Membre& membre)
{
	if (this != &membre) {
		nom_ = membre.nom_;
		typeMembre_ = membre.typeMembre_;


		for (int i = 0; i < billets_.size(); ++i) {
			delete billets_[i];
		}

		billets_.clear();

		for (int i = 0; i < membre.billets_.size(); i++) {
			billets_.push_back(new Billet(*membre.billets_[i]));
		}
	}

	return *this;
}


///
//- Fonction : operator<<
//- Description : fonction qui permet d afficher un membre
//- Param�tres : o, membre
//- Retour : ostream
///
ostream& operator<<(ostream& o, const Membre& membre)
{
	o << setfill(' ');
	o << "- Membre " << membre.nom_ << ":" << endl;
	o << "\t" << "- Billets :" << endl;
	for (int i = 0; i < membre.billets_.size(); i++) {
		o << *membre.billets_[i];
		if (membre.billets_[i]->getTypeBillet() == Billet_Regulier) {
			BilletRegulier* billetRegulier = static_cast<BilletRegulier*>(membre.billets_[i]);
			o << *billetRegulier;
		}
		else if (membre.billets_[i]->getTypeBillet() == Flight_Pass) {
			FlightPass* flightPass = static_cast<FlightPass*>(membre.billets_[i]);
			o << *flightPass;
		}
	}
	
	

	return o << endl;
}
