///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : membrePremium.cpp
//- Date : 8 Octobre 2019
//- Description : Cr�ation de la classe membre premium .
///


#include "membrePremium.h"

///
//- Fonction : MembrePremium
//- Description : fonction qui permet d initialiser les attributs de membre premium avec des parametres
//- Param�tres : nom
//- Retour : aucun
///
MembrePremium::MembrePremium(const string& nom)
	:MembreRegulier(nom,Membre_Premium),
	joursRestants_(JOUR_RESTANT_INITIALE),
	pointsCumules_(0)
{

}

//setters

///
//- Fonction : setJourRestants
//- Description : fonction qui permet de set le nombre de jour restants
//- Param�tres : jourrestants
//- Retour : aucun
///
void MembrePremium::setJourRestants(unsigned int joursRestants) {
	joursRestants_ = joursRestants;
}


///
//- Fonction : modifierPointsCumules
//- Description : fonction qui permet de modifier le nombre de points cumules
//- Param�tres : pointCumulee
//- Retour : aucun
///
void MembrePremium::modifierPointsCumules(unsigned int pointCumulee) {
	pointsCumules_ += pointCumulee;
}


//getters

///
//- Fonction : getJourRestants
//- Description : fonction qui permet de get le nombre de jour restant
//- Param�tres : aucun
//- Retour : int
///
unsigned int MembrePremium::getJourRestants() const {
	return joursRestants_;

}


///
//- Fonction : getPointCumulee
//- Description : fonction qui permet de get le nombre de point cumule
//- Param�tres : aucun
//- Retour : int
///
unsigned int MembrePremium::getpointsCumulee() const {
	return pointsCumules_;

}


///
//- Fonction : ajouterBillet
//- Description : fonction qui permet d ajouter un billet pour un membre premium
//- Param�tres : pnr, prix, od, tarif, typeBilllet, dateVol
//- Retour : aucun
///
void MembrePremium::ajouterBillet(const string& pnr, double prix, const string& od, TarifBillet tarif, TypeBillet typeBillet, const string& dateVol) {
	MembreRegulier::ajouterBillet(pnr, prix, od, tarif, typeBillet, dateVol);
	modifierPointsCumules(calculerPoints(billets_[billets_.size() - 1]));

}


///
//- Fonction : acheterCoupon
//- Description : fonction qui permet d acheter un coupon
//- Param�tres : coupon
//- Retour : aucun
///
void MembrePremium::acheterCoupon(Coupon* coupon) {

	double rabais = 0.00001*(pointsCumules_ );
	if (rabais > 0.2) {
		rabais = 0.2;
	}
	
	double nouveauCout=coupon->getCout()*(1 - rabais);

	if (points_ > nouveauCout) {
		*this += coupon;
		modifierPoints(-nouveauCout);
	}	

}

///
//- Fonction : operator<<
//- Description : fonction qui permet d afficher un membre premium
//- Param�tres : os , membrePremium
//- Retour : ostream
///
ostream& operator<<(ostream& os, const MembrePremium& membrePremium) {
	os << "\t" << "- Points cumulee: "<< membrePremium.getpointsCumulee() << endl;
	os << "\t" << "- Jours premium restant: "<< membrePremium.getJourRestants() << endl;

	return os;
}
