///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : billetRegulier.cpp
//- Date : 8 Octobre 2019
//- Description : Cr�ation de la classe billet regulier.
///


#include "billetRegulier.h"

///
//- Fonction : BilletRegulier
//- Description : fonction qui permet d initialiser les attributs d un billet regulier
//- Param�tres : pnr, nomPassager, prix, od ,tarif , datevol et type de billet
//- Retour : Aucun
///
BilletRegulier::BilletRegulier(const string& pnr, const string& nomPassager, double prix, const string& od, TarifBillet tarif, const string& dateVol, TypeBillet typeBillet):
	Billet(pnr,nomPassager,prix,od,tarif,typeBillet), 
	dateVol_ (dateVol)
{

}

///
//- Fonction : getDateVol
//- Description : fonction qui permet de get la date du vol
//- Param�tres : aucun
//- Retour : string
///
string BilletRegulier::getDateVol() const {
	return dateVol_;
}


///
//- Fonction : setDateVol
//- Description : fonction qui permet de set la date du vol
//- Param�tres : dateVol
//- Retour : aucun
///
void BilletRegulier::setDateVol(string dateVol) {
	dateVol_ = dateVol;

}


///
//- Fonction : operator<<
//- Description : fonction qui permet d afficher un billet Regulier
//- Param�tres : o et billet 
//- Retour : ostream
///
ostream& operator<<(ostream& o, const BilletRegulier& billet) {
	o << "\t\t\t" << setw(11) << "- Vol le" << ": " << billet.dateVol_ << endl;

	return o;

}