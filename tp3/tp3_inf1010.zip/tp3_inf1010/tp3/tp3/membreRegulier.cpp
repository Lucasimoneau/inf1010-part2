///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : membreRegulier.cpp
//- Date : 8 Octobre 2019
//- Description : Cr�ation de la classe membre Regulier.
///


#include "membreRegulier.h"


///
//- Fonction : MembreRegulier
//- Description : fonction qui permet d initialiser les attributs de membre regulier avec des parametres
//- Param�tres : nom, typeMembre
//- Retour : aucun
///
MembreRegulier::MembreRegulier(const string& nom, TypeMembre typeMembre)
	:Membre(nom, typeMembre),
	points_(0)
{

}


int MembreRegulier::getPoints() const
{
	return points_;
}

vector<Coupon*> MembreRegulier::getCoupons() const
{
	return coupons_;
}

void MembreRegulier::acheterCoupon(Coupon* coupon)
{
	if (points_ > coupon->getCout()) {
		*this += coupon;
		modifierPoints(-coupon->getCout());
	}
}


Membre& MembreRegulier::operator+=(Coupon* coupon)
{
	coupons_.push_back(coupon);

	return *this;
}

Membre& MembreRegulier::operator-=(Coupon* coupon)
{
	for (int i = 0; i < coupons_.size(); i++) {
		if (coupons_[i] == coupon) {
			coupons_[i] = coupons_[coupons_.size() - 1];
			coupons_.pop_back();
			return *this;
		}
	}

	return *this;
}

void MembreRegulier::modifierPoints(int points)
{
	points_ += points;
}

///
//- Fonction : ajouterBillet
//- Description : fonction qui permet d ajouter un billet regulier
//- Param�tres : onr , prix, od, tarif, typeBillet, dateVol
//- Retour : aucun
///
void MembreRegulier::ajouterBillet(const string& pnr, double prix, const string& od, TarifBillet tarif, TypeBillet typeBillet, const string& dateVol) {
	Membre::ajouterBillet(pnr, prix, od, tarif, typeBillet,dateVol);
	modifierPoints(calculerPoints(billets_[billets_.size() - 1]));

}


double MembreRegulier::calculerPoints(Billet* billet) const
{
	double bonus = 0;
	switch (billet->getTarif()) {
	case TarifBillet::PremiumEconomie:
		bonus = 50;
		break;
	case TarifBillet::Affaire:
		bonus = 150;
		break;
	case TarifBillet::Premiere:
		bonus = 300;
		break;
	default:
		break;
	}

	return billet->getPrix() * 0.10 + bonus;
}

///
//- Fonction : operator<<
//- Description : fonction qui permet d afficher un membre regulier
//- Param�tres : os, membreRegulier
//- Retour : ostream
///
ostream& operator<<(ostream& os, const MembreRegulier& membreRegulier) {
	for (int i = 0; i < membreRegulier.getCoupons().size(); i++) {
		os << membreRegulier.getCoupons()[i];
	}
	os << "\t" <<"- Points: "<< membreRegulier.getPoints()<<endl;
	os<< "\t" << "- Coupons :" << endl << endl;
	return os;
}


