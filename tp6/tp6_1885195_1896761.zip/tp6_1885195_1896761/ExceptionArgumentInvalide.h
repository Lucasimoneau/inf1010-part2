#ifndef EXCEPTIONARGUMENTINVALIDE_H
#define EXCEPTIONARGUMENTINVALIDE_H

#include <QException>
#include <QString>

class ExceptionArgumentInvalide : public QException {

public:
    ExceptionArgumentInvalide(const char* s): s_(s){}
    virtual const char* what() const{ return s_; }

private:
    const char* s_;

};
#endif // EXCEPTIONARGUMENTINVALIDE_H
