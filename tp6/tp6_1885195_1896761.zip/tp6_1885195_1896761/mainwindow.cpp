/********************************************
* Titre: Travail pratique #6 - mainwindow.cpp
* Date: 21 novembre 2019
* Auteur: Allan BEDDOUK
*******************************************/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ExceptionArgumentInvalide.h"


#include <QComboBox>
#include <QLabel>
#include <QHBoxLayout>
#include <QMessageBox>
#include <algorithm>


Q_DECLARE_METATYPE(Membre*)
Q_DECLARE_METATYPE(Billet*)
Q_DECLARE_METATYPE(Coupon*)

using namespace std;

MainWindow::MainWindow(vector<Coupon*> coupons, vector<Membre*> membres, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow), coupons_(coupons), membres_(membres)
{
    ui->setupUi(this);
    setup();

}

MainWindow::~MainWindow()
{
    for(auto membre : membres_)
        delete membre;

    for (auto coupon: coupons_)
         delete coupon;

    delete ui;
}

void MainWindow::setup(){
   setMenu();
   setUI();
   chargerCoupons();
   chargerBillets();
   chargerMembres();
   nettoyerVue();
}

void MainWindow::afficherMessage(QString msg) {
    // TODO
    QMessageBox* msg1=new QMessageBox();
    msg1->setText(msg);
    msg1->exec();

}

void MainWindow::setMenu() {
    // TODO
    QMenu* doc=new QMenu("fichier");

    //bouton quitter
    QAction* boutonQuitter=new QAction("Quitter",this);
    connect (boutonQuitter,SIGNAL(triggered()),this,SLOT(close()));
    doc->addAction(boutonQuitter);

    //bouton Nettoyer
    QAction* boutonNettoyer=new QAction("Nettoyer vue",this);
    connect (boutonNettoyer,SIGNAL(triggered()),this,SLOT(nettoyerVue()));
    doc->addAction(boutonNettoyer);

    menuBar()->addMenu(doc);
}

void MainWindow::setUI(){

    //liste des billets
    QLabel* billetsLabel = new QLabel();
    billetsLabel->setText("Billets : ");
    listeBillets_ = new QListWidget(this);
    listeBillets_->setSortingEnabled(true);

    // TODO
    //connection de la liste de billet avec la fonction selectionnerBillet
    connect(listeBillets_, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(selectionnerBillet(QListWidgetItem*)));

    // Boutons radios Type de billets
    boutonsRadioTypeBillets_.push_back(new QRadioButton("Regulier", this));
    boutonsRadioTypeBillets_.push_back(new QRadioButton("Regulier Solde", this));
    boutonsRadioTypeBillets_.push_back(new QRadioButton("FlightPass", this));
    boutonsRadioTypeBillets_.push_back(new QRadioButton("FlightPass Solde", this));

    QHBoxLayout* boutonsRadioBilletsLayout = new QHBoxLayout();
    for(QRadioButton* bouton : boutonsRadioTypeBillets_)
        boutonsRadioBilletsLayout->addWidget(bouton);


    // Liste deroulante pour choisir le Membre
    choixMembreBillet_ = new QComboBox(this);
    choixMembreBillet_->addItem("Membres");
    ajouterMembresDansComboBox(choixMembreBillet_);

    //Champ pour le PNR
    editeurPNR_ = new QLineEdit();

    QHBoxLayout* pnrLayout = new QHBoxLayout();
    pnrLayout->addWidget(new QLabel("PNR : "));
    pnrLayout->addWidget(editeurPNR_);


    //Champ pour le prix
    editeurPrixBillet_ = new QLineEdit();
    editeurPrixBillet_->setValidator(new QDoubleValidator(0, 10000, 2, this));

    QHBoxLayout* prixBilletLayout = new QHBoxLayout();
    prixBilletLayout->addWidget(new QLabel("Prix : "));
    prixBilletLayout->addWidget(editeurPrixBillet_);


    //Champ pour l'Od
    editeurOD_ = new QLineEdit();

    QHBoxLayout* odBilletLayout = new QHBoxLayout();
    odBilletLayout->addWidget(new QLabel("Od : "));
    odBilletLayout->addWidget(editeurOD_);


    //Champ pour le Tarif du Billet
    choixTarifBillet_ = new QComboBox(this);
    choixTarifBillet_->addItem("Tarif Billet");
    choixTarifBillet_->addItem("Economie");
    choixTarifBillet_->addItem("Premium economie");
    choixTarifBillet_->addItem("Affaire");
    choixTarifBillet_->addItem("Premiere");

    //Champ pour la date de vol
    editeurDateVol_ = new QLineEdit();

    QHBoxLayout* dateVolLayout = new QHBoxLayout();
    dateVolLayout->addWidget(new QLabel("Date de Vol : "));
    dateVolLayout->addWidget(editeurDateVol_);


    //Champ pour le pourcentage solde du billet
    editeurPourcentageSoldeBillet_ = new QLineEdit();
    editeurPourcentageSoldeBillet_->setValidator(new QDoubleValidator(0, 10000, 2, this));

    QHBoxLayout* pourcentageSoldeBilletLayout = new QHBoxLayout();
    pourcentageSoldeBilletLayout->addWidget(new QLabel("Pourcentage Solde Billet : "));
    pourcentageSoldeBilletLayout->addWidget(editeurPourcentageSoldeBillet_);

    //Champ pour les jours restants
    editeurUtilisationsRestantesFlightPass_ = new QLineEdit();
    editeurUtilisationsRestantesFlightPass_->setValidator(new QDoubleValidator(0, 10000, 2, this));
    editeurUtilisationsRestantesFlightPass_->setDisabled(true);

    QHBoxLayout* utilisationsRestantesLayout = new QHBoxLayout();
    utilisationsRestantesLayout->addWidget(new QLabel("Utilisations Restantes : "));
    utilisationsRestantesLayout->addWidget(editeurUtilisationsRestantesFlightPass_);


    //Bouton ajouter billet
    // TODO

    //creation d'un bouton
    boutonAjouterBillet=new QPushButton(this);
    //ajout de text sur le bouton
    boutonAjouterBillet->setText("Ajouter Billet");
    //connection du bouton avec la fonction ajouterBillet
    connect(boutonAjouterBillet, SIGNAL(clicked()), this, SLOT(ajouterBillet()));


    //ligne seprant les ajouts de billets
    //et les ajouts de coupons
    QFrame* horizontaleFrameLine = new QFrame();
    horizontaleFrameLine->setFrameShape(QFrame::HLine);

    //liste des coupons
    QLabel* couponsLabel = new QLabel();
    couponsLabel->setText("Coupons : ");
    listeCoupons_ = new QListWidget(this);
    listeCoupons_->setSortingEnabled(true);

    // TODO
    //connection avec la liste de coupons et la fonction selectionnerCoupon
    connect(listeCoupons_, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(selectionnerCoupon(QListWidgetItem*)));

    //Champ pour le code du coupon
    editeurCodeCoupon_ = new QLineEdit();

    QHBoxLayout* codeCouponLayout = new QHBoxLayout();
    codeCouponLayout->addWidget(new QLabel("Code : "));
    codeCouponLayout->addWidget(editeurCodeCoupon_);

    //Champ pour le rabais du coupon
    editeurRabaisCoupon_ = new QLineEdit();
    editeurRabaisCoupon_->setValidator(new QDoubleValidator(0, 10000, 2, this));

    QHBoxLayout* rabaisCouponLayout = new QHBoxLayout();
    rabaisCouponLayout->addWidget(new QLabel("Rabais : "));
    rabaisCouponLayout->addWidget(editeurRabaisCoupon_);

    //Champ pour le cout du coupon
    editeurCoutCoupon_ = new QLineEdit();
    editeurCoutCoupon_->setValidator(new QDoubleValidator(0, 10000, 2, this));

    QHBoxLayout* coutCouponLayout = new QHBoxLayout();
    coutCouponLayout->addWidget(new QLabel("Cout : "));
    coutCouponLayout->addWidget(editeurCoutCoupon_);


    //Bouton ajouter coupon
    // TODO

    //Creation nouveau bouton
    boutonAjouterCoupon=new QPushButton(this);
    //Ajout de text sur le bouton
    boutonAjouterCoupon->setText("Ajouter Coupon");
    //connection du bouton avec la fonction ajouterCoupon
    connect(boutonAjouterCoupon,SIGNAL(clicked()),this,SLOT(ajouterCoupon()));

    //ligne seprant les ajouts de coupons
    //et les informations des membres
    QFrame* horizontaleFrameLine2 = new QFrame();
    horizontaleFrameLine2->setFrameShape(QFrame::HLine);

    //selecteur pour les membres
    QComboBox* choixMembre = new QComboBox(this);
    choixMembre->addItem("Tout Afficher"); // Index 0
    choixMembre->addItem("Afficher Membres Reguliers"); // Index 1
    choixMembre->addItem("Afficher Membres Premium"); // Index 2

    // TODO
    //connection du type de membre avec la fonction de filtrage
    connect(choixMembre,SIGNAL(currentIndexChanged(int)),this,SLOT(filtrerListe(int)));


    //liste des membres
    QLabel* membresLabel = new QLabel();
    membresLabel->setText("Membres : ");
    listeMembres_ = new QListWidget(this);
    listeMembres_->setSortingEnabled(true);

    // TODO
    //connection de la liste de membres avec la fonction selectionnerMembre
    connect(listeMembres_, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(selectionnerMembre(QListWidgetItem*)));

    //Champ pour les points du Membres Regulier
    editeurPoints_ = new QLineEdit();
    editeurPoints_->setValidator(new QDoubleValidator(0, 10000, 2, this));

    QHBoxLayout* pointsMembreLayout = new QHBoxLayout();
    pointsMembreLayout->addWidget(new QLabel("Points : "));
    pointsMembreLayout->addWidget(editeurPoints_);


    //Champ pour les points cumules du Membres Regulier
    editeurPointsCumules_ = new QLineEdit();
    editeurPointsCumules_->setValidator(new QDoubleValidator(0, 10000, 2, this));
    QHBoxLayout* pointsCumMembreLayout = new QHBoxLayout();
    pointsCumMembreLayout->addWidget(new QLabel("Points Cumules : "));
    pointsCumMembreLayout->addWidget(editeurPointsCumules_);

    //Champ pour les points cumules du Membres Regulier
    editeurJoursRestants_ = new QLineEdit();
    editeurJoursRestants_->setValidator(new QDoubleValidator(0, 10000, 2, this));
    QHBoxLayout* joursRestantsLayout = new QHBoxLayout();
    joursRestantsLayout->addWidget(new QLabel("Jours Restants : "));
    joursRestantsLayout->addWidget(editeurJoursRestants_);


    //Layout de gauche
    QVBoxLayout* layoutHautGauche = new QVBoxLayout;

    layoutHautGauche->addWidget(billetsLabel);
    layoutHautGauche->addWidget(listeBillets_);

    layoutHautGauche->addWidget(couponsLabel);
    layoutHautGauche->addWidget(listeCoupons_);

    layoutHautGauche->addWidget(choixMembre);

    layoutHautGauche->addWidget(membresLabel);
    layoutHautGauche->addWidget(listeMembres_);

    //layout de droite
     QVBoxLayout* layoutHautDroite = new QVBoxLayout;
     layoutHautDroite->addWidget(choixMembreBillet_);
     layoutHautDroite->addLayout(boutonsRadioBilletsLayout);
     layoutHautDroite->addLayout(pnrLayout);
     layoutHautDroite->addLayout(prixBilletLayout);
     layoutHautDroite->addLayout(odBilletLayout);
     layoutHautDroite->addWidget(choixTarifBillet_);
     layoutHautDroite->addLayout(dateVolLayout);
     layoutHautDroite->addLayout(pourcentageSoldeBilletLayout);
     layoutHautDroite->addLayout(utilisationsRestantesLayout);

     //TODO
     //Ajout bouton Billet
     layoutHautDroite->addWidget(boutonAjouterBillet);
     layoutHautDroite->addWidget(horizontaleFrameLine);
     layoutHautDroite->addLayout(codeCouponLayout);
     layoutHautDroite->addLayout(rabaisCouponLayout);
     layoutHautDroite->addLayout(coutCouponLayout);

     //TODO
     //Ajout bouton coupon
     layoutHautDroite->addWidget(boutonAjouterCoupon);
     layoutHautDroite->addWidget(horizontaleFrameLine2);
     layoutHautDroite->addLayout(pointsMembreLayout);
     layoutHautDroite->addLayout(pointsCumMembreLayout);
     layoutHautDroite->addLayout(joursRestantsLayout);


    //ligne verticale
    QFrame* verticalFrameLine = new QFrame;
    verticalFrameLine->setFrameShape(QFrame::VLine);

    //Layout du haut
    QHBoxLayout* layoutHaut = new QHBoxLayout;
    layoutHaut->addLayout(layoutHautGauche);
    layoutHaut->addWidget(verticalFrameLine);
    layoutHaut->addLayout(layoutHautDroite);

    //Main layout
    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->addLayout(layoutHaut);

    QWidget* widget = new QWidget;
    widget->setLayout(mainLayout);

    setCentralWidget(widget);

    string title = "Bienvenue sur PolyAir !" ;
    setWindowTitle(title.c_str());
}

void MainWindow::chargerBillets(){
    listeBillets_->clear();

    for(Membre* membre: membres_){
        for(Billet* billet: membre->getBillets())
        {
            QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(billet->getPnr()), listeBillets_);
            item->setData(Qt::UserRole, QVariant::fromValue<Billet*>(billet));
        }
    }

}

void MainWindow::chargerCoupons(){
    listeCoupons_->clear();
    for (auto coupon: coupons_){

        QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(coupon->getCode()), listeCoupons_);
        item->setData(Qt::UserRole, QVariant::fromValue<Coupon*>(coupon));
    }

}

void MainWindow::chargerMembres(){
    listeMembres_->clear();
    for (auto membre: membres_){

        QListWidgetItem* item = new QListWidgetItem(
            QString::fromStdString(membre->getNom()) , listeMembres_);
        item->setData(Qt::UserRole, QVariant::fromValue<Membre*>(membre));
    }
}

void MainWindow::ajouterMembresDansComboBox(QComboBox* list){
    for(Membre* membre : membres_){
        list->addItem(QString::fromStdString(membre->getNom()));
    }
}

void MainWindow::nettoyerVue() {

    //appel des fonction qui nettoye la vue des billets, coupons et membres
    nettoyerVueBillets();
    nettoyerVueCoupons();
    nettoyerVueMembres();

    // Listes
    //nettoyage des listes billet, coupons et membres
    listeBillets_->clearSelection();
    listeCoupons_->clearSelection();
    listeMembres_->clearSelection();

    //mettre a jour ces listes
    chargerBillets();
    chargerCoupons();
    chargerMembres();
}

void MainWindow::nettoyerVueBillets(){
    //reset toute les valeurs d un billet
    editeurOD_->clear();
    editeurPNR_->clear();
    editeurDateVol_->clear();
    editeurPrixBillet_->clear();
    editeurPourcentageSoldeBillet_->clear();
    editeurUtilisationsRestantesFlightPass_->clear();
    choixTarifBillet_->setCurrentIndex(0);
    choixMembreBillet_->setCurrentIndex(0);

    //degriser les inputs
    boutonAjouterBillet->setDisabled(false);
    editeurOD_->setDisabled(false);
    editeurPNR_->setDisabled(false);
    editeurDateVol_->setDisabled(false);
    editeurPrixBillet_->setDisabled(false);
    editeurPourcentageSoldeBillet_->setDisabled(false);
    editeurUtilisationsRestantesFlightPass_->setDisabled(false);
    choixTarifBillet_->setDisabled(false);
    choixMembreBillet_->setDisabled(false);

    //reset les boutons radio type billets
    for(auto it =boutonsRadioTypeBillets_.begin();it!= boutonsRadioTypeBillets_.end();it++){
        (*it)->setAutoExclusive(false);
        (*it)->setDisabled(false);
        (*it)->setChecked(false);
    }

}

void MainWindow::nettoyerVueCoupons(){
    //reset les valeurs d un coupon
    editeurRabaisCoupon_->clear();
    editeurCoutCoupon_->clear();
    editeurCodeCoupon_->clear();

    //Degriser les inputs et bouton
    editeurRabaisCoupon_->setDisabled(false);
    editeurCoutCoupon_->setDisabled(false);
    editeurCodeCoupon_->setDisabled(false);
    boutonAjouterCoupon->setDisabled(false);
}

void MainWindow::nettoyerVueMembres(){
    //reset les valeurs d'un membre
    editeurJoursRestants_->setText(QString::fromStdString("N/a"));
    editeurPoints_->setText(QString::fromStdString("N/a"));
    editeurPointsCumules_->setText(QString::fromStdString("N/a"));

    //degriser les inputs d un membre
    editeurJoursRestants_->setDisabled(true);
    editeurPoints_->setDisabled(true);
    editeurPointsCumules_->setDisabled(true);

}

void MainWindow::selectionnerBillet(QListWidgetItem* item){
    // TODO
    //chercher les donnees du billet choisi
    Billet* billet= item->data(Qt::UserRole).value<Billet*>();

    //mettre les valeurs du billet dans les inputs
    editeurOD_->setText(QString::fromStdString(billet->getOd()));
    editeurPNR_->setText(QString::fromStdString(billet->getPnr()));
    editeurPrixBillet_->setText(QString::number(billet->getPrix()));
    editeurDateVol_->setText(QString::fromStdString("N/a"));
    editeurPourcentageSoldeBillet_->setText(QString::fromStdString("N/a"));
    editeurUtilisationsRestantesFlightPass_->setText(QString::fromStdString("N/a"));

    //verifier si le billet est en solde
    if(auto solde=dynamic_cast<Solde*>(billet)){
        editeurPourcentageSoldeBillet_->setText(QString::number(solde->getPourcentageSolde()));
    }

    //verifier si le billet est regulier
    if(auto billetRegulier=dynamic_cast<BilletRegulier*>(billet)){
        editeurDateVol_->setText(QString::fromStdString(billetRegulier->getDateVol()));
    }

    //verifier si le billet est regulier
    if (auto flighPass=dynamic_cast<FlightPass*>(billet)){
        editeurUtilisationsRestantesFlightPass_->setText(QString::number(flighPass->getNbUtilisationsRestante()));
    }

    //verifier le membre choisi
    for(int i=0; i<listeMembres_->count();i++){
        QString nom = QString::fromStdString(billet->getNomPassager());
        if (choixMembreBillet_->itemText(i)==nom){
            choixMembreBillet_->setCurrentIndex(i);
            break;
        }
    }

    //permet de check les boutons radio type billet
    for(auto it=boutonsRadioTypeBillets_.begin();it!=boutonsRadioTypeBillets_.end();it++){
        (*it)->setChecked(false);
        if  (((typeid(*billet) == typeid(BilletRegulier))&& ((*it)->text().endsWith("Regulier"))) ||
             ((typeid(*billet) == typeid(FlightPass)) && ((*it)->text().endsWith("FlightPass"))) ||
             ((typeid(*billet) == typeid(BilletRegulierSolde)) && ((*it)->text().endsWith("Regulier Solde"))) ||
             ((typeid(*billet) == typeid(FlightPassSolde)) && ((*it)->text().endsWith("FlightPass Solde")))) {
            (*it)->setChecked(true);
        }
    }

    //griser les inputs et les boutons
    boutonAjouterBillet->setDisabled(true);
    editeurOD_->setDisabled(true);
    editeurPNR_->setDisabled(true);
    editeurPrixBillet_->setDisabled(true);
    editeurDateVol_->setDisabled(true);
    editeurPourcentageSoldeBillet_->setDisabled(true);
    editeurUtilisationsRestantesFlightPass_->setDisabled(true);
    choixTarifBillet_->setDisabled(true);
    choixMembreBillet_->setDisabled(true);
    choixTarifBillet_->setCurrentIndex(int(billet->getTarif())+1);

}

void MainWindow::selectionnerCoupon(QListWidgetItem* item ){

    // TODO
    //prendre les donnees du coupon choisi
    Coupon* coupon= item->data(Qt::UserRole).value<Coupon*>();

    //mettre les donnees dans les inputs
    editeurRabaisCoupon_->setText(QString::number(coupon->getRabais()));
    editeurCoutCoupon_->setText(QString::number(coupon->getCout()));
    editeurCodeCoupon_->setText(QString::fromStdString(coupon->getCode()));

    //griser les inputs et le bouton
    boutonAjouterCoupon->setDisabled(true);
    editeurRabaisCoupon_->setDisabled(true);
    editeurCoutCoupon_->setDisabled(true);
    editeurCodeCoupon_->setDisabled(true);

}

void MainWindow::selectionnerMembre(QListWidgetItem* item){
    // TODO
    //prendre les donnees du membre choisi
    Membre* membre=item->data(Qt::UserRole).value<Membre*>();

    //mettre inputs nul
    editeurJoursRestants_->setText(QString::fromStdString("N/a"));
    editeurPoints_->setText(QString::fromStdString("N/a"));
    editeurPointsCumules_->setText(QString::fromStdString("N/a"));

    //check si le membre est regulier
    if (auto membreRegulier=dynamic_cast<MembreRegulier*>(membre)){
        editeurPoints_->setText(QString::number(membreRegulier->getPoints()));
    }

    //check si le membre est premium
    if(auto membrePremium=dynamic_cast<MembrePremium*>(membre)){
        editeurPoints_->setText(QString::fromStdString("N/a"));
        editeurJoursRestants_->setText(QString::number(membrePremium->getJourRestants()));
        editeurPointsCumules_->setText(QString::number(membrePremium->getpointsCumulee()));
    }

    //griser les inputs
    editeurJoursRestants_->setDisabled(true);
    editeurPoints_->setDisabled(true);
    editeurPointsCumules_->setDisabled(true);
}

void MainWindow::ajouterBillet(){
    // TODO
    Membre* membre;
    Billet* nouveauBillet;
    QRadioButton* billetType= nullptr;

    //check le bouton choisi
    for(auto it=boutonsRadioTypeBillets_.begin();it!=boutonsRadioTypeBillets_.end();it++){
        if((*it)->isChecked()){
            billetType=*it;
            break;
        }
    }

    //methode try and catch
    try{
        bool valide;
        string pnr=editeurPNR_->text().toStdString();
        string nom=choixMembreBillet_->currentText().toStdString();
        string od=editeurOD_->text().toStdString();
        membre=trouverMembreParNom(nom);

        //plusieurs type d erreurs possible
        if(choixTarifBillet_->currentIndex()==0){
            throw ExceptionArgumentInvalide("erreur, le tarif du billet est inconnu");
        }

        if (billetType==nullptr){
            throw ExceptionArgumentInvalide("erreur, le type de billet est inconnu");
        }

        if (nom=="Membres"){
            throw ExceptionArgumentInvalide("erreur, pas de membre assigner au billet");
        }

        if (pnr==""){
            throw ExceptionArgumentInvalide("erreur, le pnr du billet n'est pas valide");
        }

        double prix= editeurPrixBillet_->text().toDouble(&valide);
        if(valide==false){
            throw ExceptionArgumentInvalide("erreur, le prix du billet n'est pas valide");
        }

        double pourcentageSolde=editeurPourcentageSoldeBillet_->text().toDouble(&valide);
        if(billetType->text().endsWith("Solde")){
            if(valide==false){
                throw ExceptionArgumentInvalide("erreur, le solde du billet n'est pas valide");
            }
        }


        if(billetType->text().startsWith("Regulier")){
            string date=editeurDateVol_->text().toStdString();
            if(date==""){
                throw ExceptionArgumentInvalide("erreur, la date du vol est inconnu");
            }

            if(billetType->text().endsWith("Solde")){
                nouveauBillet=new BilletRegulierSolde(pnr,prix,od,getTarifBillet(),date,pourcentageSolde);
            }
            else{
               nouveauBillet=new BilletRegulier(pnr,prix,od,getTarifBillet(),date);
            }
        }

        else {

            if(billetType->text().endsWith("Solde")){
                nouveauBillet=new FlightPassSolde(pnr,prix,od,getTarifBillet(),pourcentageSolde);
            }
            else{
                nouveauBillet=new FlightPass(pnr,prix,od,getTarifBillet());
            }
        }

    }
    //renvoie de l erreur
    catch(ExceptionArgumentInvalide& e){
        afficherMessage(QString::fromStdString(e.what()));
        return ;

    }

    //si aucun erreur ajout du billet
    membre->ajouterBillet(nouveauBillet);

    //mise a jour des billets
    chargerBillets();

    //afficher un message pour prevenir du bon fonctionnement de la fonction
    afficherMessage(QString::fromStdString("le billet a ete rajoute"));
}

void MainWindow::ajouterCoupon(){
    // TODO
    Coupon* nouveauCoupon;
    //utilisation de la methode try and catch
    try{
        bool valide;
        string codeCoupon=editeurCodeCoupon_->text().toStdString();
        int coutCoupon=editeurCoutCoupon_->text().toInt(&valide);

        //plusieur erreurs possible
        if(codeCoupon==""){
            throw ExceptionArgumentInvalide("erreur, le code du coupon est vide");
        }

        if (valide==false){
            throw ExceptionArgumentInvalide("erreur, le cout du coupon n'est pas valide");
        }

        double rabaisCoupon=editeurRabaisCoupon_->text().toDouble(&valide);
        if (valide==false){
            throw ExceptionArgumentInvalide("erreur, le rabais du coupon n'est pas valide");
        }
        nouveauCoupon=new Coupon(codeCoupon,rabaisCoupon,coutCoupon);

    }
    catch(ExceptionArgumentInvalide& e){
        afficherMessage(QString::fromStdString(e.what()));
        return ;

    }
    //ajout du nouveau coupon si aucun problemes se presentent
    coupons_.push_back(nouveauCoupon);

    //mise a jour des coupons
    chargerCoupons();

    //afficher un message de bon fonctionnemnt de la fonction
    afficherMessage(QString::fromStdString("le coupon a ete rajoute"));
}

void MainWindow::filtrerListe(int index){
    // TODO
    //boucle prenant le nombre de membre
    for(int i=0; i<listeMembres_->count();i++){
        Membre* membre=listeMembres_->item(i)->data(Qt::UserRole).value<Membre*>();
        //permet de cacher les membres appartenant pas a la categorie voulu
        if (filtrerMasque(membre,index)){
            listeMembres_->item(i)->setHidden(true);
        }
        else{
            listeMembres_->item(i)->setHidden(false);
        }
    }
}

bool MainWindow::filtrerMasque(Membre* membre, int index) {
    // TODO
    //regarder si le membre appartient au membre regulier ou premium
    if(index==1){
        return typeid (MembreRegulier) != typeid (*membre);
    }
    else if (index==2){
       return typeid (MembrePremium) != typeid (*membre);
    }
    return false;
}

TarifBillet MainWindow::getTarifBillet(){
    //TODO
    //retourner le tarif du billet
    return static_cast<TarifBillet>(choixTarifBillet_->currentIndex());

}

Membre* MainWindow::trouverMembreParNom(const string& nom){
   //TODO
    //chercher le membre voulu et le retourner
    for(int i=0;i<membres_.size();i++){
        if(membres_[i]->getNom()==nom){
            return membres_[i];
        }
    }
    return nullptr;
}
