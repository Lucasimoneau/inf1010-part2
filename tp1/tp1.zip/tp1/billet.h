/*
 * Date : 1 Septembre 2019
 * Auteur : Wassim Khene
 */

#ifndef BILLET_H/Users/lucassimoneau/Google Drive/Poly/2eme annee/tp inf1010/tp1_1885195_1896761/billet.h
#define BILLET_H

#include <string>
#include <iostream>
#include <iomanip>
#include "def.h"

using namespace std;

class Billet {
public:
	// TODO: Implementer toutes les methodes
	Billet();
	Billet(const string& pnr, const string& nomPassager, double prix, const string& od, TarifBillet tarif, const string& dateVol);

	// TODO: Implementer si necessaire
	//pas necessaire
	//~Billet();

	// Getters
	string getPnr() const;
	string getNomPassager() const;
	double getPrix() const;
	string getOd() const;
	TarifBillet getTarif() const;
	string getDateVol() const;

	// Setters
	void setPnr(const string& pnr);
	void setNomPassager(const string& nomPassager);
	void setPrix(double prix);
	void setOd(const string& od);
	void setTarif(TarifBillet tarif);
	void setDateVol(const string& dateVol);

	string formatTarif(TarifBillet tarif);

	void afficherBillet();//a revoir
private:
	string pnr_;
	string nomPassager_;
	double prix_;
	string od_;
	TarifBillet tarif_;
	string dateVol_;
};
#endif // !BILLET_H

