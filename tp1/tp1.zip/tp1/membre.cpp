///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : membre.cpp
//- Date : 12 Septembre 2019
//- Description : Cr�ation de la classe membre.
///

#include "membre.h"



///
//- Fonction : Membre::Membre
//- Description : constructeur par defaut
//- Param�tres : Aucun
//- Retour : Aucun
///
Membre::Membre(): nom_ (""), points_(0), nbBillets_(0), capaciteBillets_(CAPACITE_INITIALE),  
				  nbCoupons_(0), capaciteCoupons_(CAPACITE_INITIALE), billets_(new Billet*[CAPACITE_INITIALE]), coupons_(new Coupon*[CAPACITE_INITIALE]) {


}



///
//- Fonction : Membre::Membre
//- Description : constructeur par parametre
//- Param�tres : nom
//- Retour : Aucun
///
Membre::Membre(const string& nom) : points_(0), nbBillets_(0), capaciteBillets_(CAPACITE_INITIALE),
									nbCoupons_(0), capaciteCoupons_(CAPACITE_INITIALE), billets_(new Billet*[CAPACITE_INITIALE]), coupons_(new Coupon*[CAPACITE_INITIALE]) {

	nom_ = nom; 
	
}



///
//- Fonction : Membre::~Membre
//- Description : destructeur
//- Param�tres : Aucun
//- Retour : Aucun
///
Membre:: ~Membre() {
	for (int i = 0; i < nbBillets_; i++) {
		delete billets_[i];
	}
	delete[] billets_;

	for (int i = 0; i < nbCoupons_; i++) {
		delete coupons_[i];
	}
	delete[] coupons_;
	
 }




///
//- Fonction : Membre::getNom
//- Description : getter Nom
//- Param�tres : Aucun
//- Retour : nom_
///
string Membre::getNom() const {
	return nom_;
}




///
//- Fonction : Membre::getPoints
//- Description : getter points
//- Param�tres : Aucun
//- Retour : points_
///
int Membre::getPoints() const {
	return points_;
}





///
//- Fonction : Membre::getBillets
//- Description : getter billets
//- Param�tres : Aucun
//- Retour : billets_
///
Billet** Membre::getBillets() const {
	return billets_;
}



///
//- Fonction : Membre::getNbBillets
//- Description : getter nombre billets
//- Param�tres : Aucun
//- Retour : nbBillets_
///
int Membre::getNbBillets() const {
	return nbBillets_;
}




///
//- Fonction : Membre::getCapaciteBillets
//- Description : getter capacite Billets
//- Param�tres : Aucun
//- Retour : capaciteBillets_
///
int Membre::getCapaciteBillets() const {
	return capaciteBillets_;
}




///
//- Fonction : Membre::getCoupons
//- Description : getter coupons
//- Param�tres : Aucun
//- Retour : coupons_
///
Coupon** Membre::getCoupons() const {
	return coupons_;
}




///
//- Fonction : Membre::getNbCoupons
//- Description : getter nombre coupons
//- Param�tres : Aucun
//- Retour : nbCoupons_
///
int Membre::getNbCoupons() const {
	return nbCoupons_;

}




///
//- Fonction : Membre::getCapaciteCoupons
//- Description : getter capacite coupons
//- Param�tres : Aucun
//- Retour : capaciteCoupons_
///
int Membre::getCapaciteCoupons() const {
	return capaciteCoupons_;
}




///
//- Fonction : Membre::setNom
//- Description : setter Nom
//- Param�tres : nom
//- Retour : Aucun
///
void Membre::setNom(const string& nom) {
	nom_ = nom;
}



///
//- Fonction : Membre::modifierPoints
//- Description : fonction pour modifier points
//- Param�tres : points
//- Retour : Aucun
///
void Membre::modifierPoints(int points) {
	points_ += points;
}



///
//- Fonction : Membre::ajouterBillet
//- Description : fonction pour ajouter un billet
//- Param�tres : pnr, prix, od, tarif, dateVol
//- Retour : Aucun
///
void Membre::ajouterBillet(const string& pnr, double prix, const string& od, TarifBillet tarif, const string& dateVol) {
	if (nbBillets_ >= capaciteBillets_) {

		if (capaciteBillets_ > 0) {
			capaciteBillets_ = capaciteBillets_ * 2;
		}
		else {
			capaciteBillets_ = 10;
		}

		Billet** billets = new Billet*[capaciteBillets_];

		for (int i = 0; i < nbBillets_; i++) {
			billets[i] = billets_[i];
		}
		delete[] billets_;

		billets_ = billets;
	}

	Billet* nouveauBillet = new Billet (pnr, nom_, prix, od, tarif, dateVol);
	billets_[nbBillets_] =  nouveauBillet;
	nbBillets_++;

	modifierPoints(calculerPoints(nouveauBillet));
}




///
//- Fonction : Membre::ajouterCoupon
//- Description : fonction pour ajouter coupon
//- Param�tres : coupon
//- Retour : Aucun
///
void Membre::ajouterCoupon(Coupon* coupon) {
	if (nbCoupons_ >= capaciteCoupons_) {

		if (capaciteCoupons_ > 0) {
			capaciteCoupons_ = capaciteCoupons_ * 2;
		}
		else {
			capaciteCoupons_ = 10;
		}

		Coupon** coupons = new Coupon*[capaciteCoupons_];

		for (int i = 0; i < nbCoupons_; i++) {
			coupons[i] = coupons_[i];
		}
		delete[] coupons_;

		coupons_ = coupons;
	}
	coupons_[nbCoupons_] = coupon;
	nbCoupons_++;
}




///
//- Fonction : Membre::retirerCoupon
//- Description : fonction pour retirer un coupo n
//- Param�tres : coupon
//- Retour : Aucun
///
void Membre::retirerCoupon(Coupon* coupon) {

	for (int i = 0; i < nbCoupons_; i++) {
		if (coupons_[i]->getCode() == coupon->getCode()) {
			coupons_[i]=nullptr;
			for (int j = i; j < nbCoupons_- 1; j++) {
				coupons_[j] = coupons_[j + 1];
			}
			coupons_[nbCoupons_-1]=nullptr;//-1
			nbCoupons_--;
			break;
		}
	}
}



///
//- Fonction : Membre::acheterCoupon
//- Description : fonction pour acheter un coupon
//- Param�tres : coupon
//- Retour : Aucun
///
void Membre::acheterCoupon(Coupon* coupon) {

	if (points_ >= coupon->getCout()) {
		ajouterCoupon(coupon);
		modifierPoints(-coupon->getCout());
	}


}



///
//- Fonction : Membre::calculerPoint
//- Description : fonction calculer points
//- Param�tres : billet
//- Retour : nombre de points calculer
///
double Membre::calculerPoints(Billet* billet) {

	double pointAjoute = billet->getPrix() * 0.1;

	if (billet->getTarif() == TarifBillet::Economie) {

		return (pointAjoute);
	}
	else if (billet->getTarif() == TarifBillet::PremiumEconomie) {

		return (50 + pointAjoute);
	}
	else if (billet->getTarif() == TarifBillet::Affaire) {

		return (150 + pointAjoute);
	}
	else if (billet->getTarif() == TarifBillet::Premiere) {

		return (300 + pointAjoute);

	}

}



///
//- Fonction : Membre::afficherMembre
//- Description : fonction pour afficher un membre
//- Param�tres : Aucun
//- Retour : Aucun
///
void Membre::afficherMembre() {
	cout << "- Membre " << nom_ << ":" << endl;
	cout << "	- Points : " << points_<<endl;
	cout << "	- Billets : " << endl;
	for (int i = 0; i < nbBillets_; i++) {
		billets_[i]->afficherBillet();
	}
	cout << "	- Coupons : " << endl;
	for (int i = 0; i < nbCoupons_; i++) {
		coupons_[i]->afficherCoupon();
	}

}