///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : billet.cpp
//- Date : 12 Septembre 2019
//- Description : Cr�ation de la classe Billet.
///

#include "billet.h"


///
//- Fonction : Billet::Billet
//- Description : Le constructeur par d�faut
//- Param�tres : Aucun
//- Retour : Aucun
///
Billet::Billet():	pnr_(""), nomPassager_(""), prix_(0.0), od_(""), 
					tarif_(TarifBillet::Economie), dateVol_("") {
	

}


///
//- Fonction : Billet::Billet
//- Description : Le constructeur par parametre
//- Param�tres : pnr, nomPassager, prix, od, tarif, dateVol
//- Retour : Aucun
///
Billet::Billet(const string& pnr, const string& nomPassager, double prix, const string& od, TarifBillet tarif, const string& dateVol) {
	pnr_ = pnr;
	nomPassager_ = nomPassager;
	prix_ = prix;
	od_ = od;
	tarif_=tarif;
	dateVol_ = dateVol;

}


///
//- Fonction : Billet::getPnr
//- Description : getter pnr
//- Param�tres : Aucun
//- Retour : pnr_
///
string Billet::getPnr() const {
	return pnr_;

}


///
//- Fonction : Billet::getNomPassager
//- Description : getter nom passager
//- Param�tres : Aucun
//- Retour : nomPassager_
///
string Billet::getNomPassager() const {
	return nomPassager_;

}


///
//- Fonction : Billet::getPrix
//- Description : getter prix
//- Param�tres : Aucun
//- Retour : prix_
///
double Billet::getPrix() const {
	return prix_;

}


///
//- Fonction : Billet::getOd
//- Description : getter od
//- Param�tres : Aucun
//- Retour : od_
///
string Billet::getOd()const {
	return od_;

}


///
//- Fonction : Billet::getTarif
//- Description : getter tarif
//- Param�tres : Aucun
//- Retour : tarif_
///
TarifBillet Billet::getTarif() const {
	return tarif_;

}


///
//- Fonction : Billet::getDateVol
//- Description : getter date vol
//- Param�tres : Aucun
//- Retour : dateVol_
///
string Billet::getDateVol()const {
	return dateVol_;

}



///
//- Fonction : Billet::setPnr
//- Description : setter pnr
//- Param�tres : pnr
//- Retour : Aucun
///
void Billet::setPnr(const string& pnr) {
	pnr_ = pnr;

}



///
//- Fonction : Billet::setNomPassager
//- Description : setter nomPassager
//- Param�tres : nomPassager
//- Retour : Aucun
///
void Billet::setNomPassager(const string& nomPassager) {
	nomPassager_ = nomPassager;

}



///
//- Fonction : Billet::setPrix
//- Description : setter prix
//- Param�tres : prix
//- Retour : Aucun
///
void Billet::setPrix(double prix) {
	prix_ = prix;

}



///
//- Fonction : Billet::setOd
//- Description : setter od
//- Param�tres : od
//- Retour : Aucun
///
void Billet::setOd(const string& od) {
	od_ = od;

}



///
//- Fonction : Billet::setTarif
//- Description : setter tarif
//- Param�tres : tarif
//- Retour : Aucun
///
void Billet::setTarif(TarifBillet tarif) {
	tarif_ = tarif;

}



///
//- Fonction : Billet::setDateVol
//- Description : setter dateVol
//- Param�tres : dateVol
//- Retour : Aucun
///
void Billet::setDateVol(const string& dateVol) {
	dateVol_ = dateVol;

}


///
//- Fonction : Billet::formatTarif
//- Description : fonction pour convertir le tarif en string
//- Param�tres : tarif
//- Retour : string
///
string Billet::formatTarif(TarifBillet tarif) {
	
	if (tarif == TarifBillet::Economie) {
		return "Economie";
	}
	else if (tarif == TarifBillet::PremiumEconomie) {
		return "Premium economie";
	}
	else if (tarif == TarifBillet::Affaire) {
		return "Affaire";
	}
	else if (tarif == TarifBillet::Premiere) {
		return "Premiere";
	}
	
}

///
//- Fonction : Billet::afficherBillet 
//- Description : fonction pour l affichage d un billet
//- Param�tres : aucun
//- Retour : aucun
///
void Billet::afficherBillet() {
	cout << "		-Billet " << pnr_ << " (Classe : " << formatTarif(tarif_) << ")"<< endl;
	cout << "			-Passager  : " << nomPassager_ << endl;
	cout << "			-Prix      : " << prix_<< "$" << endl;
	cout << "			-Trajet    : " << od_ << endl;
	cout << "			-Vol le    : " << dateVol_ << endl;

}