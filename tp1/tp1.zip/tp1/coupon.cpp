///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : coupon.cpp
//- Date : 12 Septembre 2019
//- Description : Cr�ation de la classe coupn.
///

#include "coupon.h"

///
//- Fonction : Coupon::Coupon
//- Description : constructeur par defaut
//- Param�tres : Aucun
//- Retour : Aucun
///
Coupon::Coupon():  code_(""), rabais_(0.0) ,
				   cout_(0) {
	

}


///
//- Fonction : Coupon::Coupon
//- Description : constructeur par parametre
//- Param�tres : code , rabais, cout
//- Retour : Aucun
///
Coupon::Coupon(const string& code, double rabais, int cout) {
	code_ = code;
	rabais_ = rabais;
	cout_ = cout;

}


///
//- Fonction : Coupon::getCode
//- Description : getter code
//- Param�tres : Aucun
//- Retour : code_
///
string Coupon::getCode() const {
	return code_;

}


///
//- Fonction : Coupon::getRabais
//- Description : getter rabais
//- Param�tres : Aucun
//- Retour : rabais_
///
double Coupon::getRabais() const {
	return rabais_;

}



///
//- Fonction : Coupon::getCout
//- Description : getter cout
//- Param�tres : Aucun
//- Retour : cout_
///
int Coupon::getCout() const {
	return cout_;

}



///
//- Fonction : Coupon::setCode
//- Description : setter code
//- Param�tres : code
//- Retour : Aucun
///
void Coupon::setCode(const string& code) {
	code_ = code;

}



///
//- Fonction : Coupon::setRabais
//- Description : setter rabais
//- Param�tres : rabais
//- Retour : Aucun
///
void Coupon::setRabais(double rabais) {
	rabais_ = rabais;

}



///
//- Fonction : Coupon::setCout
//- Description : setter cout
//- Param�tres : cout
//- Retour : Aucun
///
void Coupon::setCout(int cout) {
	cout_ = cout;

}


///
//- Fonction : Coupon::afficherCoupon
//- Description : fonction pour afficher un coupon
//- Param�tres : Aucun
//- Retour : Aucun
///
void Coupon::afficherCoupon() {
	cout << "			-Coupon " << code_ << "%. Rabais : " << rabais_ << "." << endl;
}