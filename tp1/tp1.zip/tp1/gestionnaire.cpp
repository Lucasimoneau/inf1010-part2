///
//- Auteurs : Lucas Simoneau, Arthur Leboiteux
//- Fichier : gestionnair.cpp
//- Date : 12 Septembre 2019
//- Description : Cr�ation de la classe gestionnaire.
///

#include "gestionnaire.h"



///
//- Fonction : Gestionnaire::Gestionnaire
//- Description : constructeur par defaut
//- Param�tres : Aucun
//- Retour : Aucun
///
Gestionnaire::Gestionnaire(): membres_(new Membre*), nbMembres_(0), capaciteMembres_(CAPACITE_INITIALE), 
							  coupons_(new Coupon*), nbCoupons_(0), capaciteCoupons_(CAPACITE_INITIALE) {
	

}

///
//- Fonction : Gestionnaire::~Gestionnaire
//- Description : destructeur
//- Param�tres : Aucun
//- Retour : Aucun
///
Gestionnaire:: ~Gestionnaire() {
	for (int i = 0; i < nbMembres_; i++) {
		delete membres_[i];
	}
	delete[] membres_;
	
	for (int i = 0; i < nbCoupons_; i++) {
		delete coupons_[i];
	}
	delete[] coupons_;

}



///
//- Fonction : Gestionnaire::getMembres
//- Description : getter membres
//- Param�tres : Aucun
//- Retour : membres_
///
Membre** Gestionnaire::getMembres() const {
	return membres_;
}



///
//- Fonction : Gestionnaire::getNbMembres
//- Description : getter nombre de membres
//- Param�tres : Aucun
//- Retour : nbMembres_
///
int Gestionnaire::getNbMembres() const {
	return nbMembres_;
}



///
//- Fonction : Gestionnaire::getCapaciteMembres
//- Description : getter capacite membres
//- Param�tres : Aucun
//- Retour : capaciteMembres_
///
int Gestionnaire::getCapaciteMembres() const {
	return capaciteMembres_;
}



///
//- Fonction : Gestionnaire::getCoupons
//- Description : getter coupons
//- Param�tres : Aucun
//- Retour : coupons_
///
Coupon** Gestionnaire::getCoupons() const {
	return coupons_;
}



///
//- Fonction : Gestionnaire::getNbCoupons
//- Description : getter nombre de coupons
//- Param�tres : Aucun
//- Retour : nbCoupons_
///
int Gestionnaire::getNbCoupons() const {
	return nbCoupons_;
}




///
//- Fonction : Gestionnaire::getCapaciteCoupons
//- Description : getter Capacite Coupons
//- Param�tres : Aucun
//- Retour : CapaciteCoupons_
///
int Gestionnaire::getCapaciteCoupons() const {
	return capaciteCoupons_;
}




///
//- Fonction : Gestionnaire::ajouterMembre
//- Description : fonction ajouter membre
//- Param�tres : nomMembre
//- Retour : Aucun
///
void Gestionnaire::ajouterMembre(const string& nomMembre) {

	if (nbMembres_ >= capaciteMembres_) {

		if (capaciteMembres_ > 0) {
			capaciteMembres_ = capaciteMembres_ * 2;
		}
		else {
			capaciteMembres_ = 10;
		}

		Membre** membres = new Membre*[capaciteMembres_];

		for (int i = 0; i < nbMembres_; i++) {
			membres[i] = membres_[i];
		}
		delete[] membres_;

		membres_ = membres;
	}
	Membre* nouveauMembre = new Membre(nomMembre);
	membres_[nbMembres_] = nouveauMembre;
	nbMembres_++;

}




///
//- Fonction : Gestionnaire::ajouterCoupon
//- Description : fonction ajouter coupon
//- Param�tres : code, rabais, cout
//- Retour : Aucun
///
void Gestionnaire::ajouterCoupon(const string& code, double rabais, int cout) {

	if (nbCoupons_ >= capaciteCoupons_) {

		if (capaciteCoupons_ > 0) {
			capaciteCoupons_ = capaciteCoupons_ * 2;
		}
		else {
			capaciteCoupons_ = 10;
		}

		Coupon** coupons = new Coupon*[capaciteCoupons_];

		for (int i = 0; i < nbCoupons_; i++) {
			coupons[i] = coupons_[i];
		}
		delete[] coupons_;

		coupons_ = coupons;
	}
	Coupon* nouveauCoupon = new Coupon(code, rabais, cout);
	coupons_[nbCoupons_] = nouveauCoupon;
	nbCoupons_++;

}





///
//- Fonction : Gestionnaire::trouverMembre
//- Description : fonction trouver membre
//- Param�tres : nomMembre
//- Retour : un membre
///
Membre* Gestionnaire::trouverMembre(const string& nomMembre) {
	for (int i = 0; i < nbMembres_; i++) {
		if (membres_[i]->getNom() == nomMembre) {
			return membres_[i];
		}

	}
	cout << "Erreur, le membre n'est pas trouve" << endl;
	return nullptr;
}





///
//- Fonction : Gestionnaire::assignerBillet
//- Description : fonction assigner Billet
//- Param�tres : nomMembre, pnr, prixBase, od, tarif, dateVol, utiliserCoupon
//- Retour : Aucun
///
void Gestionnaire::assignerBillet(const string& nomMembre, const string& pnr, double prixBase, const string& od, TarifBillet tarif, const string& dateVol, bool utiliserCoupon) {
	if (utiliserCoupon == true) {
		prixBase = appliquerCoupon(trouverMembre(nomMembre), prixBase);
	}
	trouverMembre(nomMembre)->ajouterBillet(pnr, prixBase, od, tarif, dateVol);



}




///
//- Fonction : Gestionnaire::appliquerCoupon
//- Description : fonction appliquer coupon
//- Param�tres : membre, prix
//- Retour : prix apres apllication du coupon
///
double Gestionnaire::appliquerCoupon(Membre* membre, double prix) {
	if (membre->getNbCoupons() == 0) {
		cout << "erreur aucun coupon est disponible" << endl;
		return prix;
	}
	double meilleurCoupon = (membre->getCoupons()[0])->getRabais();
	int position = 0;
	for (int i = 1; i < membre->getNbCoupons(); i++) {
		if ( (membre->getCoupons()[i])->getRabais() > meilleurCoupon) {
			meilleurCoupon = (membre->getCoupons()[i])->getRabais();
			position = i;
		}
	}
	prix -= (prix*meilleurCoupon);
	membre->retirerCoupon(membre->getCoupons()[position]);
	return prix;
}




///
//- Fonction : Gestionnaire::acheterCoupon
//- Description : fonction acheter coupon
//- Param�tres : nomMembre
//- Retour : Aucun
///
void Gestionnaire::acheterCoupon(const string& nomMembre) {
	if (nbCoupons_ != 0) {
		double meilleurCoupon = 0;
		int position = 0;
		for (int i = 0; i < nbCoupons_; i++) {
			if (coupons_[i]->getRabais() > meilleurCoupon && coupons_[i]->getCout() < trouverMembre(nomMembre)->getPoints()) {
				meilleurCoupon = coupons_[i]->getRabais();
				position = i;
			}
		}
		if (meilleurCoupon!=0) {
			trouverMembre(nomMembre)->modifierPoints(-coupons_[position]->getCout());
			trouverMembre(nomMembre)->ajouterCoupon(coupons_[position]);
		}

		else {
			cout << "erreur: " << nomMembre << "n a pas assez de points pour acheter un coupon" << endl;
		}

	}
	else {
		cout << "erreur aucun coupon est disponible";
	}
}




///
//- Fonction : Gestionnaire::afficherInfos
//- Description : fonction afficher les infomations
//- Param�tres : Aucun
//- Retour : Aucun
///
void Gestionnaire::afficherInfos() {
	for (int i = 0; i < nbMembres_; i++) {
		membres_[i]->afficherMembre();
		cout << endl << endl;
	}
}