/********************************************
* Titre: Travail pratique #5 - gestionnaireMembres.cpp
* Date: 30 octobre 2019
* Auteur: Allan BEDDOUK & Jeffrey LAVALLEE
*******************************************/

#include "GestionnaireMembres.h"
#include <numeric>

void GestionnaireMembres::assignerBillet(Billet* billet, const string& nomMembre, int rabaisCoupon)
{
	Membre* membre = conteneur_[nomMembre];

	if (membre == nullptr) {
		delete billet;
		return;
	}

	double prix = billet->getPrix();

	if (auto solde = dynamic_cast<Solde*>(billet)) {
		prix = solde->getPrixBase();
	}

	
	prix -= rabaisCoupon;
	

	if (auto membrePremium = dynamic_cast<MembrePremium*>(membre)) {
		double rabais = 0.005 * membrePremium->getpointsCumulee() / 1000;
		if (rabais > 0.1)
			rabais = 0.1;

		prix *= (1 - rabais);
	}

	billet->setPrix(prix);
	membre->ajouterBillet(billet);
}



double GestionnaireMembres::calculerRevenu() const
{
	//TODO
	double revenu = 0;
	for (auto it = conteneur_.begin(); it != conteneur_.end(); it++) {

		vector<Billet*> tmp = it->second->getBillets();
		for_each(tmp.begin(), tmp.end(), [&revenu](Billet* const billet) {
			revenu += billet->getPrix();
		});
	};

	return revenu;
}

int GestionnaireMembres::calculerNombreBilletsEnSolde() const
{
	//TODO
	int nbBilletsSolde = 0;
	
	for(auto it =conteneur_.begin(); it!=conteneur_.end();it++) {
		vector<Billet*> tmp = it->second->getBillets();
		for_each(tmp.begin(), tmp.end(), [&nbBilletsSolde](Billet* billet) {
			if (dynamic_cast<Solde*>(billet)) {
				++nbBilletsSolde;
			}
		});
	};

	return nbBilletsSolde;
}


//TODO
Billet* GestionnaireMembres::getBilletMin(string nomMembre) const {

	Membre* membreTrouve = nullptr;

	for_each(conteneur_.begin(), conteneur_.end(), [&membreTrouve, &nomMembre](pair<string, Membre*> membre) {//&
		if (membre.second->getNom()==nomMembre){
			membreTrouve = membre.second;
		}
	});
	
	if (membreTrouve == nullptr) {
		cout << "le membre n'a pas ete trouve dans la fonction getBilletMin";
		return nullptr;
	}

	else{
		vector<Billet*> billets = membreTrouve->getBillets();

		vector<Billet*>::iterator it=min_element(billets.begin(), billets.end(), [](Billet* billet1, Billet* billet2) {

			if (billet2->getPrix() > billet1->getPrix()) {
				return true;
			}

			else {
				return false;
			}
		});

		return *it;

	}

}


//TODO
Billet* GestionnaireMembres::getBilletMax(string nomMembre) const {

	Membre* membreTrouve = nullptr;

	for_each(conteneur_.begin(), conteneur_.end(), [&membreTrouve, &nomMembre](pair<string, Membre*> membre) {//&
		if (membre.second->getNom() == nomMembre) {
			membreTrouve = membre.second;
		}
	});

	if (membreTrouve == nullptr) {
		cout << "le membre n'a pas ete trouve dans la fonction getBilletMax";
		return nullptr;
	}

	else {
		vector<Billet*> billets = membreTrouve->getBillets();

		vector<Billet*>::iterator it = max_element(billets.begin(), billets.end(), [](Billet* billet1, Billet* billet2) {

			if (billet2->getPrix() < billet1->getPrix()) {
				return true;
			}

			else {
				return false;
			}
		});

		return *it;

	}
}


//TODO
vector<Billet*> GestionnaireMembres::trouverBilletParIntervallle(Membre* membre, double prixInf, double prixSup) const {

	IntervallePrixBillet intervalle(prixInf, prixSup);
	vector<Billet*> billets=membre->getBillets();
	vector<Billet*> billetsIntervalle;

	for_each(billets.begin(), billets.end(), [&intervalle, &billetsIntervalle](Billet* const billet) {
		if (intervalle(billet)) {
			billetsIntervalle.push_back(billet);
		}
	});

	return billetsIntervalle;
}


void GestionnaireMembres::afficher(ostream& o) const
{
	//TODO
	o << "=================== ETAT ACTUEL DU PROGRAMME ==================\n\n";

	for(auto it=conteneur_.begin(); it!=conteneur_.end(); it++){
		it->second->afficher(o);
	};
}
